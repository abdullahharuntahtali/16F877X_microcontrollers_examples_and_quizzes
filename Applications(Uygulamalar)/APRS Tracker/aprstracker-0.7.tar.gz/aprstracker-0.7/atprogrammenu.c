/*
 *	atprogrammenu.c
 *
 *	Copyright Jeroen Vreeken (pe1rxq@amsat.org) 2003
 *
 *	Published under the terms of the GNU General Public License
 *	version 2.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <time.h>
#include <termios.h>

unsigned char ee_data[64];

void usage(void)
{
	printf("\n");
	printf("Usage:\n");
	printf("\n");
	printf("atprogram [serial port]\n");
	printf("\n");
}


int read_eeprom(int fd_ser)
{
	char buffer[2];
	int i;

	for (i=0; i<64; i++) {
		buffer[0]='R';
		buffer[1]=i;
		write(fd_ser, buffer, 2);
		if (read(fd_ser, ee_data+i, 1)!=1)
			return -1;
	}
	
	return 0;
}

int write_eeprom(int fd_ser)
{
	unsigned char buffer[3];
	int i;

	for (i=0; i<64; i++) {
		buffer[0]='W';
		buffer[1]=i;
		buffer[2]=ee_data[i];
		write(fd_ser, buffer, 3);
		if (read(fd_ser, buffer, 1)!=1)  {
			return -1;
		}
		if (buffer[0]!=ee_data[i]) {
			return 1;
		}
	}
	
	return 0;
}

void print_content(void)
{
	int i;
	printf("\n");
	printf("****************************************************************************\n");
	printf("Eeprom contents:\n");
	printf("----------------------------------------------------------------------------\n");
	printf("Source address: \t");
	for (i=0; i<6; i++) {
		printf("%c", ee_data[i+7]>>1);
	}
	printf("-%c\n", ee_data[13]>>1);
	printf("Destination address:\t");
	for (i=0; i<6; i++) {
		printf("%c", ee_data[i]>>1);
	}
	printf("-%c\n", ee_data[6]>>1);
	printf("Beacon interval:\t%d\n", ee_data[0x1c]);
	printf("TX Delay count: \t%d\n", ee_data[0x1d]);
	printf("Symbol table:\t\t%c\n", ee_data[0x1e]);
	printf("Symbol id:\t\t%c\n", ee_data[0x1f]);
	ee_data[63]=0;
	printf("Beacontext:\t\t%s\n", ee_data+0x20);
	printf("****************************************************************************\n");
	printf("\n");
}

void leave_programming(int fd_ser)
{
	write(fd_ser, "X", 1);
}

int enter_programming(int fd_ser)
{
	unsigned char buffer[5];
	fd_set	fdread;
	struct timeval timeout;
	
	leave_programming(fd_ser);
	write(fd_ser, "!", 1);
	usleep(100000);
	FD_ZERO(&fdread);
	FD_SET(fd_ser, &fdread);
	timeout.tv_sec=1;
	timeout.tv_usec=0;
	select(fd_ser+1, &fdread, NULL, NULL, &timeout);
	if (!FD_ISSET(fd_ser, &fdread)) {
		return 1;
	}
	if (read(fd_ser, buffer, 4)!=4) {
		return 1;
	}
	if (!strncmp(buffer, "AT", 2)) {
		printf("APRSTracker ver: %d memver: %d in programming mode\n", 
		    buffer[2], buffer[3]);
		if (buffer[3]!=0x01)
			return 1;
		return 0;
	}
	return 1;
}

int init_serial(char *serdev)
{
	int fd_ser;
	struct termios ser_tio;

	if ((fd_ser=open(serdev, O_RDWR))<0)
		return -1;
	if (tcgetattr(fd_ser, &ser_tio)<0)
		return -1;
	cfmakeraw(&ser_tio);
	ser_tio.c_cflag = B4800 | CS8 | CLOCAL | CREAD;
	if (tcsetattr(fd_ser, TCSANOW, &ser_tio)<0)
		return -1;
	return fd_ser;
}

void set_call(char *callsign, int offset, int end)
{
	int i;
	
	for (i=0; i<6; i++) {
		if (*callsign && *callsign!='-') {
			if (*callsign < '0' || *callsign > '9')
				*callsign&=~32;
			ee_data[offset+i]=(*callsign)<<1;
			callsign++;
		} else {
			ee_data[offset+i]=' '<<1;
		}
	}
	if (*callsign=='-')
		callsign++;
	if (*callsign)
		ee_data[offset+6]=*callsign<<1;
	else
		ee_data[offset+6]='0'<<1;
	if (end) {
		ee_data[offset+6]|=1;
	}
}

void set_comment(char *comment)
{
	if (!strlen(comment)>31) {
		ee_data[32]=0;
	} else {
		strcpy(ee_data+32, comment);
	}
}

void print_menu(void)
{
	printf("****************************************************************************\n");
	printf("Options:\n");
	printf("----------------------------------------------------------------------------\n");
	printf("0\tReread EEPROM\n");
	printf("1\tSet Source address\n");
	printf("2\tSet Txdelay\n");
	printf("3\tSet Beacon interval\n");
	printf("4\tSet Symbol table\n");
	printf("5\tSet Symbol id\n");
	printf("6\tSet Beacontext\n");
	printf("****************************************************************************\n");
	printf("Type your choice and press Enter: ");
	fflush(0);
}

int mainloop (int argc, char **argv)
{
	int fd_ser;
	char buffer[80];
	char value[80];
	int i=0;

	printf("\n");
	printf("****************************************************************************\n");
	printf("APRSTracker programmer\n");
	printf("Copyright Jeroen Vreeken (pe1rxq@amsat.org) 2003\n");
	printf("memver: 1\n");
	printf("****************************************************************************\n");
	printf("\n");

	printf("Initializing serial port...\n");
	if ((fd_ser=init_serial("/dev/ttyS0"))<0) {
		perror("Unable to initialize serial port");
		return 1;
	}

	printf("Connect APRSTracker to the serial port (/dev/ttyS0 or COM1) and press Enter\n");
	read(0, buffer, 80);
	do { 
		printf("Putting APRSTracker in programming mode...\n");
		if (enter_programming(fd_ser)) {
			printf("No programmable APRSTracker found\n");
			printf("Reopening serial port...\n");
			close(fd_ser);
			if ((fd_ser=init_serial("/dev/ttyS0"))<0) {
				perror("Unable to initialize serial port");
			return 1;
			}	
			if (i==1)
				goto bailout;
			printf("Retrying...\n");
		} else
			break;
		i++;
	} while (1);

	printf("Reading current eeprom contents...\n");
	if (read_eeprom(fd_ser)) {
		perror("Error reading eeprom contents");
		goto bailout;
	}

menu:
	print_content();
	print_menu();

	buffer[read(0, buffer, 79)]=0;;
	while (strlen(buffer) && 
	    (buffer[strlen(buffer)-1]=='\n' || buffer[strlen(buffer)-1]=='\r'))
	    	buffer[strlen(buffer)-1]=0;
	if (buffer[0]!='0') {
		printf("New value:");
		fflush(0);
		value[read(0, value, 79)]=0;
		while (strlen(value) && 
		    (value[strlen(value)-1]=='\n' || value[strlen(value)-1]=='\r'))
		    	value[strlen(value)-1]=0;
	}
	switch(buffer[0]) {
		case '0':
			printf("Rereading current eeprom contents...\n");
			if (read_eeprom(fd_ser)) {
				perror("Error reading eeprom contents\n");
				goto bailout;
			}
			break;
		case '1':
			printf("Setting source address...\n");
			set_call(value, 7, 0);
			break;
		case '2':
			printf("Setting txdelay...\n");
			ee_data[0x1d]=atoi(value);
			break;
		case '3':
			printf("Settingg beacon interval...\n");
			ee_data[0x1c]=atoi(value);
			break;
		case '6':
			printf("Setting comment...\n");
			set_comment(value);
			break;
		case '4':
			printf("Setting table...\n");
			ee_data[0x1e]=value[0];
			break;
		case '5':
			printf("Setting id...\n");
			ee_data[0x1f]=value[0];
			break;
		default:
			printf("Unknown option\n");
			goto menu;
	}
	printf("Writing eeprom contents...\n");
	if (write_eeprom(fd_ser)) {
		perror("Error writing eeprom");
		goto bailout;
	}
	goto menu;

bailout:
	leave_programming(fd_ser);
	return 1;
}

int main (int argc, char **argv) {
	while (1) {
		mainloop(argc, argv);
		sleep(1);
	}
	return 1;
}

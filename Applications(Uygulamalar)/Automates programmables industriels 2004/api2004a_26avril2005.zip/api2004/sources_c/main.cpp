/************************************************************************************/
/*                                                                                  */
/*                             PROGAPI 2004                                         */
/*                                                                                  */
/* programme de compilation de graphcet et de communication pour les automates 2004 */
/*                                                                                  */
/* main.cpp file                                                                    */
/*                                                                                  */
/************************************************************************************/
/*                                                                                  */
/* This project use next sources files:                                             */
/* - main.cpp : for the code (this file)                                            */
/* - main.h   : for constants (mainly for menus and GUI)                            */
/* - rsrc.rc  : ressource file for menus                                            */
/*                                                                                  */
/* This file is divided in 3 big parts:                                             */
/* - GUI                                                                            */
/* - Graphcet Compiler                                                              */
/* - RS232 communicator                                                             */
/*                                                                                  */
/* History                                                                          */
/* - v1.0 : first release (seems stable)                                            */
/* - v0.1 : 23sept2004  Ulysse Delmas-Begue : Initial development on MRC base       */
/*                                                                                  */
/* Next                                                                             */
/*                                                                                  */
/************************************************************************************/






/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

        I N C L U S I O N   /   G L O B A L   V A R I A B L E S   /   C O N S T A N T E S

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/






extern int hex_gra[2048];  // hex graphcet to put in PIC memory
extern int hex_gra_ind;  // index of hex_gra (next free place)
extern int def_ZG_START;



#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include "main.h"

#define STR_SAME 0==
#define STR_DIFF 0!=


LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);       /* Declare Callback function */
//BOOL compile_graphcet(char prj_filename[], char res_file[], int mode);  /* Base compilation function */

#define STR_CST 0
#define STR_REG 1
int str_add(char s[],int dat,int type);
void str_init(void);

#define EN_DISP_DECOMPOSE 0
#define EN_DISP_EQ_RESULT 0

#define VARTYPE_ZB 0
#define VARTYPE_ZV8 1
#define VARTYPE_ZV16 2
int load_def_file(void);
int load_gra_mem(void);
int compile(void);
int var_name_get(int adr, int type, char szName[]);
int var_adr_get(char s[],int* dat,int* type);


HINSTANCE hInst;
HDC    hdc;
HWND   hwnd;
//HFONT  My_Font=CreateFont(15,10,0,0,400,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_MODERN,"Courier");
HFONT  My_Font=CreateFont(15,10,0,0,200,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_MODERN,"Courier");

HPEN   My_Pen_Presentation=CreatePen(PS_SOLID,1,RGB_PRESENTATION_LINE);
HBRUSH My_Brush_Presentation=CreateSolidBrush(RGB_PRESENTATION_BG);

HPEN   My_Pen_Yellow=CreatePen(PS_SOLID,1,RGB(192,192,0));
HPEN   My_Pen_White =CreatePen(PS_SOLID,1,RGB(255,255,220));
HPEN   My_Pen_Green =CreatePen(PS_SOLID,1,RGB(0,255,0));
HPEN   My_Pen_Red   =CreatePen(PS_SOLID,1,RGB(255,0,0));
HPEN   My_Pen_Blue  =CreatePen(PS_SOLID,1,RGB(0,0,255));
HPEN   My_Pen_BlueL =CreatePen(PS_SOLID,1,RGB(0,0,128));
HPEN   My_Pen_Grey  =CreatePen(PS_SOLID,1,RGB(192,192,192));
HPEN   My_Pen_Black =CreatePen(PS_SOLID,1,RGB(0,0,0));
HPEN   My_Pen_GreyD =CreatePen(PS_SOLID,1,RGB(32,32,32));
HPEN   My_Pen_Pink  =CreatePen(PS_SOLID,1,RGB(255,0,255));

HBRUSH My_Brush_Yellow=CreateSolidBrush(RGB(192,192,0));
HBRUSH My_Brush_White=CreateSolidBrush(RGB(255,255,220));
HBRUSH My_Brush_Green=CreateSolidBrush(RGB(0,255,0));
HBRUSH My_Brush_Red  =CreateSolidBrush(RGB(255,0,0));
HBRUSH My_Brush_Blue =CreateSolidBrush(RGB(0,0,255));
HBRUSH My_Brush_BlueL=CreateSolidBrush(RGB(0,0,128));
HBRUSH My_Brush_Grey =CreateSolidBrush(RGB(192,192,192));
HBRUSH My_Brush_Black=CreateSolidBrush(RGB(0,0,0));
HBRUSH My_Brush_GreyD=CreateSolidBrush(RGB(32,32,32));
HBRUSH My_Brush_Pink =CreateSolidBrush(RGB(255,0,255));

char   key_char;
int    x_mouse;
int    y_mouse;
int    mode=MODE_EDIT;   //MODE_CONF
char   szDefFileName[255]="";
char   szGraFileName[255]="";
char   szHexFileName[255]="";
char   szLitFileName[255]="";
char   szConfFileName[255]="";
char   szPersonalHelpFileName[255]="";
char   szUserManualFileName[255]="";

char   szConfigPort[50]="COM1";
int    rs232_board_adr=3;
int    rs232_use_sum=1;
int    lit_put_eq=1;




/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

        F I L E S / E D I T   B O X E S   F U N C T I O N S

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/






/*****************************************************************************/
/* PROJECT FILE SELECTION , LOAD and SAVE                                    */
/*****************************************************************************/


BOOL SelectDefFile(void)
{
    OPENFILENAME ofn;

    ZeroMemory(&ofn, sizeof(ofn));
    szDefFileName[0] = '\0';

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = "Def Files (*.def)\0*.def\0All Files (*.*)\0*.*\0\0";
    ofn.lpstrFile = szDefFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "def";
    ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST /*| OFN_HIDEREADONLY*/;

    if(GetOpenFileName(&ofn)) return TRUE;

    return FALSE;
}

BOOL SelectGraFileOpen(void)
{
    OPENFILENAME ofn;

    ZeroMemory(&ofn, sizeof(ofn));
    szGraFileName[0] = '\0';

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = "Gra Files (*.gra)\0*.gra\0All Files (*.*)\0*.*\0\0";
    ofn.lpstrFile = szGraFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "gra";
    ofn.Flags = OFN_EXPLORER /*| OFN_FILEMUSTEXIST| OFN_HIDEREADONLY*/;

    if(GetOpenFileName(&ofn)) return TRUE;

    return FALSE;
}

BOOL SelectGraFileSaveAs(void)
{
    OPENFILENAME ofn;

    ZeroMemory(&ofn, sizeof(ofn));
    szGraFileName[0] = '\0';

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = "Gra Files (*.gra)\0*.gra\0All Files (*.*)\0*.*\0\0";
    ofn.lpstrFile = szGraFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "gra";
    ofn.Flags = OFN_EXPLORER /* | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY*/;

    if(GetSaveFileName(&ofn)) return TRUE;

    return FALSE;
}

BOOL LoadFile(HWND hEdit, LPSTR pszFileName)
{
    HANDLE hFile;
    BOOL bSuccess = FALSE;

    hFile = CreateFile(pszFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, 0);
    if(hFile != INVALID_HANDLE_VALUE)
    {
        DWORD dwFileSize;
        dwFileSize = GetFileSize(hFile, NULL);
        if(dwFileSize != 0xFFFFFFFF)
        {
            LPSTR pszFileText;
            pszFileText = (LPSTR)GlobalAlloc(GPTR, dwFileSize + 1);
            if(pszFileText != NULL)
            {
                DWORD dwRead;
                if(ReadFile(hFile, pszFileText, dwFileSize, &dwRead, NULL))
                {
                    pszFileText[dwFileSize] = 0; // Null terminator
                    if(SetWindowText(hEdit, pszFileText)) bSuccess = TRUE; // It worked!
                }
                GlobalFree(pszFileText);
            }
        }
        CloseHandle(hFile);
    }
    return bSuccess;
}

BOOL SaveFile(HWND hEdit, LPSTR pszFileName)
{
    HANDLE hFile;
    BOOL bSuccess = FALSE;

    hFile = CreateFile(pszFileName, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if(hFile != INVALID_HANDLE_VALUE)
    {
        DWORD dwTextLength;
        dwTextLength = GetWindowTextLength(hEdit);
        if(dwTextLength > 0)// No need to bother if there's no text.
        {
            LPSTR pszText;
            pszText = (LPSTR)GlobalAlloc(GPTR, dwTextLength + 1);
            if(pszText != NULL)
            {
                if(GetWindowText(hEdit, pszText, dwTextLength + 1))
                {
                    DWORD dwWritten;
                    if(WriteFile(hFile, pszText, dwTextLength, &dwWritten, NULL)) bSuccess = TRUE;
                }
                GlobalFree(pszText);
            }
        }
        CloseHandle(hFile);
    }
    return bSuccess;
}

BOOL LoadGraFile(void)
{
    return LoadFile(GetDlgItem(hwnd, ID_MAIN_TEXT), szGraFileName);
}


BOOL SaveGraFile(void)
{
    return SaveFile(GetDlgItem(hwnd, ID_MAIN_TEXT), szGraFileName);
}

BOOL UpdateLitHexFiles(void)
{
    char szTemp[200];

    sprintf(szTemp,"%s [%s]",PROGAPI_TITLE,szGraFileName);
    SetWindowText(hwnd,szTemp);

    if(strstr(szGraFileName,"."))
    {
        strcpy(szLitFileName,szGraFileName); strcpy(strstr(szLitFileName,"."),".lit");
        strcpy(szHexFileName,szGraFileName); strcpy(strstr(szHexFileName,"."),".hex");
        return TRUE;
    }
    else
    {
        strcpy(szLitFileName,"");
        strcpy(szHexFileName,"");
        return FALSE;
    }
    //err.add("");
    //UpdateWindow(hwnd);
}


/*****************************************************************************/
/* CLASS ERRFILE                                                                 */
/*****************************************************************************/

class cErrFile
{
    public:

    char filename[500];
    FILE* pf;

         cErrFile(void);
    void open(char szfilename[]);
    void add(char sztext[]);
    void close(void);
};

cErrFile::cErrFile(void)
{
    pf=NULL;
    filename[0]='\0';
}

void cErrFile::open(char szfilename[])
{
    strcpy(filename,szfilename);
    pf=fopen(filename,"wt");
    if(pf!=NULL) fprintf(pf,"PROGAPI DEBUG FILE\n");
    if(pf!=NULL) fclose(pf);
}

void cErrFile::add(char sztext[])
{
    pf=fopen(filename,"at");
    if(pf!=NULL) fprintf(pf,"\n%s",sztext);
    if(pf!=NULL) fclose(pf);
}

void cErrFile::close(void)
{
}

cErrFile ErrorFile;

/*****************************************************************************/
/* CLASS ERR                                                                 */
/*****************************************************************************/


#define ERR_SIZE 10000

class cErr
{
    public:

    char ch[ERR_SIZE];

         cErr(void);
    void add(char sztxt[]);
    void addeqres(char sztxt[]);
    void disp(void);
    void clr(void);
};

cErr::cErr(void)
{
    clr();
    remove("debug.txt");
    ErrorFile.open("debug.txt");
}

void cErr::clr(void)
{
    strcpy(ch,"");
    disp();
}

void cErr::disp(void)
{
    SendMessage(GetDlgItem(hwnd, ID_ERROR_TEXT), WM_SETTEXT, 0, (LPARAM) ch);
}

void cErr::add(char sztxt[])
{
    if( (strlen(ch)+2+strlen(sztxt)) < ERR_SIZE )
    {
        strcat(ch,"\r\n");
        strcat(ch,sztxt);
        disp();
    }
    ErrorFile.add(sztxt);
}

void cErr::addeqres(char sztxt[])
{
    if(EN_DISP_EQ_RESULT) add(sztxt);
}

cErr ErrorScreen;


void save_conf(void)
{
    FILE* pf;
    char  szTemp[255];

    pf=fopen(szConfFileName,"wt");
    if(pf==NULL)
    {
        sprintf(szTemp,"Cannot create file %s",szConfFileName); ErrorScreen.add(szTemp);
    }
    else
    {
        fprintf(pf,"RS232_PORT      = %s\n",szConfigPort);
        fprintf(pf,"RS232_BOARD_ADR = %d\n",rs232_board_adr);
        fprintf(pf,"RS232_USE_SUM   = %d\n",rs232_use_sum);
        fprintf(pf,"LIT_PUT_EQ      = %d\n",lit_put_eq);
        fprintf(pf,"DEF_FILE        = %s\n",szDefFileName);
        fclose(pf);
    }
}


void load_conf(void)
{
    FILE* pf;
    char  szTemp[255];
    char  szVar[100];
    char  szDat[100];
    char  szC[10];
    char  c;
    int   again;
    int   first;
    int   ret;


    // 1. Preinitialisation
    // dans les variables globales

    // 2. Create file if it does not exist
    pf=fopen(szConfFileName,"rt");
    if(pf==NULL)
    {
        sprintf(szTemp,"config file %s not found so create it",szConfFileName); ErrorScreen.add(szTemp);
        save_conf();
    }
    else fclose(pf);

    //3. Load the file
    pf=fopen(szConfFileName,"rt");
    if(pf==NULL)
    {
        sprintf(szTemp,"cannot open config file %s",szConfFileName);  ErrorScreen.add(szTemp);
    }
    else
    {
        sprintf(szTemp,"loading config file %s",szConfFileName);  ErrorScreen.add(szTemp);
        while( fscanf(pf," %s",szVar) != EOF )
        {
            if(strstr(szVar,"RS232_PORT"     )) { fscanf(pf," %c %s",&c,szDat); if(c=='=') strcpy(szConfigPort,szDat);  }
            if(strstr(szVar,"RS232_BOARD_ADR")) { fscanf(pf," %c %s",&c,szDat); if(c=='=') rs232_board_adr=atoi(szDat); }
            if(strstr(szVar,"RS232_USE_SUM"  )) { fscanf(pf," %c %s",&c,szDat); if(c=='=') rs232_use_sum=atoi(szDat);   }
            if(strstr(szVar,"LIT_PUT_EQ"     )) { fscanf(pf," %c %s",&c,szDat); if(c=='=') lit_put_eq=atoi(szDat);      }
            if(strstr(szVar,"DEF_FILE"       ))
            {
                fscanf(pf," %c",&c);
                if(c=='=')
                {
                    strcpy(szDat,"");
                    first=1;
                    do
                    {
                        again=1;
                        if(first) { if(fscanf(pf," %c",&c) == EOF) again=0; first=0;}
                        else      { if(fscanf(pf,"%c" ,&c) == EOF) again=0; }
                        if(again==1)
                        {
                            if(c=='\n') again=0;
                            else { sprintf(szC,"%c",c); strcat(szDat,szC); }
                        }
                    }
                    while(again==1);

                    strcpy(szDefFileName,szDat);

                    ret=load_def_file();
                    if(ret==0) { MessageBox(hwnd,"Cannot open the definition file\n\nPlease select one","progapi",MB_OK | MB_ICONERROR); PostMessage(hwnd,WM_COMMAND,CM_SELECTDEF,0); }
                    if(ret==2) MessageBox(hwnd,"Missing config variable in definition file\n\nPlease correct it","progapi",MB_OK | MB_ICONERROR);
                }
            }
        }
        fclose(pf);
    }

    //4. Display
    sprintf(szTemp,"- RS232_PORT      = %s",szConfigPort   ); ErrorScreen.add(szTemp);
    sprintf(szTemp,"- RS232_BOARD_ADR = %d",rs232_board_adr); ErrorScreen.add(szTemp);
    sprintf(szTemp,"- RS232_USE_SUM   = %d",rs232_use_sum  ); ErrorScreen.add(szTemp);
    sprintf(szTemp,"- LIT_PUT_EQ      = %d",lit_put_eq     ); ErrorScreen.add(szTemp);
    sprintf(szTemp,"- DEF_FILE        = %s",szDefFileName  ); ErrorScreen.add(szTemp);

}

void init_load_conf(void)
{
    GetCurrentDirectory(254,szConfFileName); strcat(szConfFileName,"\\conf.txt");
    GetCurrentDirectory(254,szPersonalHelpFileName); strcat(szPersonalHelpFileName,"\\pershelp.txt");
    GetCurrentDirectory(254,szUserManualFileName); strcat(szUserManualFileName,"\\um_api2004a.doc");
}






/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

        C O M M U N I C A T I O N    F U N C T I O N S   ( S E R I A L   R S 2 3 2 )

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/






/*------------------------------------------------------------------------------
NAME  : cSerial

DESCR : class cSerial: Permet de communiquer avec la carte.

NOTES :
------------------------------------------------------------------------------*/
class cSerial
{
    public:

    DCB     dcb;          // description de la liaison serie
    HANDLE  hCom;         // handler sur la liaison derie
    COMSTAT Status;       // pour voir si rx ok

         cSerial(void);                // constructeur (ne fait rien)
    int  init(char* name,int baud);    // ouvre le port et l'initialise
    int  close();                      // ferme le port
    int  read(int* data);              // effectue une lecture securisee sue la rs232
    int  blocking_read_timeout_100ms(int* data); // effectue une lecture securisee sue la rs232 (attend la date pendant 100ms max)
    int  write(int data);              // effectue une ecriture
    void dtr(int state);               // permet de mettre un etat sur la ligne DTR
    void rts(int state);               // permet de mettre un etat sur la ligne RTS
};


/*------------------------------------------------------------------------------
NAME  : cSerial::cSerial
DESCR : constructeur de la classe serial.
        (ne fait rien)
ARG   : void
RETURN: void
NOTES : none
------------------------------------------------------------------------------*/
cSerial::cSerial(void)
{
    hCom=NULL;
}


/*------------------------------------------------------------------------------
NAME  : init
DESCR : ouvre le port serie et l'initialise
ARG   : char* name: nom du port serie (COM1,COM2...)
        int   vitesse: (9600,19200...)
RETURN: 1 OK or 0 ERROR
NOTES : l'OS ferme automatiquement les ports lorsque l'application se ermine
------------------------------------------------------------------------------*/
int cSerial::init(char* name, int baud)
{
    char szTemp[255];

    if(hCom!=NULL) close();

    hCom=CreateFile(name,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);
    if(hCom==INVALID_HANDLE_VALUE) hCom=NULL;
    if(hCom==NULL                ) { sprintf(szTemp,"Impossible d'ouvrir le port serie (CreateFile)");   MessageBox(NULL,szTemp,"progapi",MB_OK | MB_ICONERROR); mode=MODE_PRES; return 0; }
    if(!GetCommState(hCom,&dcb))   { sprintf(szTemp,"Impossible d'ouvrir le port serie (GetCommState)"); MessageBox(NULL,szTemp,"progapi",MB_OK | MB_ICONERROR); mode=MODE_PRES; return 0; }
    if(     baud==1200)  dcb.BaudRate = CBR_1200;
    else if(baud==2400)  dcb.BaudRate = CBR_2400;
    else if(baud==4800)  dcb.BaudRate = CBR_4800;
    else if(baud==9600)  dcb.BaudRate = CBR_9600;
    else if(baud==19200) dcb.BaudRate = CBR_19200;
    else                           { sprintf(szTemp,"La vitesse specifiee n'est pas suportee");          MessageBox(NULL,szTemp,"progapi",MB_OK | MB_ICONERROR); mode=MODE_PRES; return 0; }
    dcb.ByteSize = 8;
    dcb.Parity   = NOPARITY;
    dcb.StopBits = ONESTOPBIT;
    if(!SetCommState(hCom,&dcb))   { sprintf(szTemp,"Impossible d'ouvrir le port serie (SetCommState)"); MessageBox(NULL,szTemp,"ptogapi",MB_OK | MB_ICONERROR); mode=MODE_PRES; return 0;}
    return 1;
}


/*------------------------------------------------------------------------------
NAME  : close
DESCR : ferme le port serie
ARG   : void
RETURN: 1 OK
NOTES : l'OS ferme automatiquement les ports lorsque l'application se termine
------------------------------------------------------------------------------*/
int cSerial::close(void)
{
    if(hCom==NULL) return 0;

    CloseHandle(hCom);
    hCom=NULL;
    return 1;
}


/*------------------------------------------------------------------------------
NAME  : cSerial::read
DESCR : effectue une lecture securise d'un octet sur la rs232
ARG   : int* data pointeur sur la donnee lue
RETURN: 1 ok or 0 nothing
NOTES : none
------------------------------------------------------------------------------*/
int cSerial::read(int* data)
{
    if(hCom==NULL) return 0;

    *data=0;
    DWORD num;
    DWORD buf[1];
    DWORD No_Error;

    ClearCommError(hCom,&No_Error,&Status);
    if(Status.cbInQue==0) return 0;
    ReadFile(hCom,buf,1,&num,NULL);
    *data=(int)buf[0];
    *data=(*data)&0xff;
    return 1;
}

/*------------------------------------------------------------------------------
NAME  : cSerial::blocking_read_timeout_100ms
DESCR : effectue une lecture securise d'un octet sur la rs232 (attend la date pendant 100ms max)
ARG   : int* data pointeur sur la donnee lue
RETURN: 1 ok or 0 nothing
NOTES : none
------------------------------------------------------------------------------*/
int cSerial::blocking_read_timeout_100ms(int* data)
{
    if(hCom==NULL) return 0;

    *data=0;
    DWORD num;
    DWORD buf[1];
    DWORD No_Error;
    int i;

    i=0;
    do
    {
        ClearCommError(hCom,&No_Error,&Status);
        if(Status.cbInQue==0) {Sleep(1); i++; if(i==100) return 0;}
    }
    while(Status.cbInQue==0);

    ReadFile(hCom,buf,1,&num,NULL);
    *data=(int)buf[0];
    *data=(*data)&0xff;
    return 1;
}

/*------------------------------------------------------------------------------
NAME  : cSerial::write
DESCR : ecrit 1 octet
ARG   : void
RETURN: 1 ok
NOTES : none
------------------------------------------------------------------------------*/
int cSerial::write(int data)
{
    if(hCom==NULL) return 0;

    DWORD num;
    DWORD buf[1];

    buf[0]=(DWORD)(data&0xff);
    WriteFile(hCom,buf,1,&num,NULL);
    return 1;
}


/*------------------------------------------------------------------------------
NAME  : cSerial::dtr
DESCR : permet de mettre un etat sur la ligne DTR
ARG   : int state: etat de la ligne DTR: 0 pour -12V et 1 pour +12V
RETURN: void
NOTES : none
------------------------------------------------------------------------------*/
void cSerial::dtr(int state)
{
    if(hCom==NULL) return;

    if(state==0) EscapeCommFunction(hCom,CLRDTR);
    else         EscapeCommFunction(hCom,SETDTR);
}


/*------------------------------------------------------------------------------
NAME  : cSerial::rts
DESCR : ermet de mettre un etat sur la ligne RTS
ARG   : int state: etat de la ligne RTS: 0 pour -12V et 1 pour +12V
RETURN: void
NOTES : none
------------------------------------------------------------------------------*/
void cSerial::rts(int state)
{
    if(hCom==NULL) return;

    if(state==0) EscapeCommFunction(hCom,CLRRTS);
    else         EscapeCommFunction(hCom,SETRTS);
}


int table[8192];


int load_table(char* szFilename)
{
    FILE* pf;
    int i;
    unsigned int nb_word,adr,op,dath,datl,sum;
    char c;


    pf=fopen(szFilename,"rt");
    if(pf==NULL) { printf("\nCannot open file %s",szFilename); return 0; }

    printf("\nLoading %s",szFilename);

    for(i=0;i<8192;i++) table[i]=-1;

    while(1)
    {
        if(fscanf(pf," %c",&c)==EOF) break; //remove :
        fscanf(pf," %02x",&nb_word); nb_word=nb_word/2;
        fscanf(pf," %04x",&adr); adr=adr/2;
        fscanf(pf," %02x",&op);

        if(op==0) for(i=0;i<nb_word;i++)
        {
            fscanf(pf," %02x",&datl);
            fscanf(pf," %02x",&dath);
            table[adr+i]=(dath<<8)+datl;
        }

        fscanf(pf," %02x",&sum);
    }

    fclose(pf);

    for(i=0;i<8192;i++) if(table[i]!=-1) printf("\n%04x %04x",i,table[i]);

    return 1;
}


/*****************************************************************************/
/* FIN LIAISON SERIE                                                         */
/*****************************************************************************/
cSerial   serial;


#define OP_RR      0
#define OP_RR16    1
#define OP_REE     2
#define OP_RFL     3
#define OP_WR      4
#define OP_WR16    5
#define OP_WEE     6
#define OP_WFL     7
#define OP_AD      8
#define OP_SETCLR  9
#define OP_GOTO   10
#define OP_CALL   11


int exchange2(int board_adr, int op, int dath, int datl, int* datth, int* dattl, int en_ack, int en_sum)
{
    char szTemp[100];
    char szTemp2[100];
    char szTemp3[100];
    char szTemp4[100];
    int sel,sum,bmt_ack,bmt_dath,bmt_datl,bmt_sum, b_read_op;


    board_adr=rs232_board_adr;
    if(rs232_use_sum==0) en_sum=0;

    if(serial.hCom==NULL) return 0;

    b_read_op=0;
    if(op==OP_RR || op==OP_RR16 || op==OP_REE || op==OP_RFL) b_read_op=1;
    
    //TX:

    sel=0x80+board_adr;
    if(en_ack) sel+=0x10;
    if(en_sum) sel+=0x20;

    if(dath&0x80) op+=0x20; dath&=0x7f;
    if(datl&0x80) op+=0x10; datl&=0x7f;
    sum=(sel+op+dath+datl)&0x7f;

    serial.write(sel);
    serial.write(op);
    if(b_read_op==0) { serial.write(dath); serial.write(datl); }
    if(en_sum) serial.write(sum);

    sprintf(szTemp2," T%02x%02x",sel,op);
    if(b_read_op==0) sprintf(szTemp3,"%02x%02x",dath,datl); else sprintf(szTemp3,"----");
    if(en_sum) sprintf(szTemp4,"%02x",sum); else sprintf(szTemp4,"--");
    sprintf(szTemp,"%s%s%s",szTemp2,szTemp3,szTemp4);
    //RX:
    //Sleep(100);

    if(datth!=NULL) *datth=0;
    if(dattl!=NULL) *dattl=0;
    bmt_dath=bmt_datl=0;

    if(en_ack==0)
    {
        strcat(szTemp," R");
        ErrorScreen.add(szTemp);
        MessageBox(NULL,szTemp,"progapi",MB_OK | MB_ICONERROR);
        return 1;
    }

    if(serial.blocking_read_timeout_100ms(&bmt_ack)==0)
    {
        strcat(szTemp," PB-ACK");
        ErrorScreen.add(szTemp);
        MessageBox(NULL,szTemp,"progapi",MB_OK| MB_ICONERROR);
        return 0;
    }

    if(bmt_ack&1) strcat(szTemp," SUMERROR-REPORTED");
    if(bmt_ack&2) strcat(szTemp," UNKNOWN-REPORTED");

    if((bmt_ack&3)==0)
    if(b_read_op)
    {
        if( serial.blocking_read_timeout_100ms(&bmt_dath)==0) strcat(szTemp," PB-DATH");
        if( serial.blocking_read_timeout_100ms(&bmt_datl)==0) strcat(szTemp," PB-DATL");;
        if(bmt_ack&0x20) bmt_dath|=0x80;
        if(bmt_ack&0x10) bmt_datl|=0x80;
    }

    if(en_sum) { if (serial.blocking_read_timeout_100ms(&bmt_sum)==0) strcat(szTemp," PB-SUM"); }

    sprintf(szTemp2," R%02x",bmt_ack); strcat(szTemp,szTemp2);
    if((bmt_ack&3)==0 && b_read_op) sprintf(szTemp2,"%02x%02x",bmt_dath,bmt_datl,bmt_sum); else sprintf(szTemp2,"----");
    strcat(szTemp,szTemp2);
    if(en_sum) { sprintf(szTemp2,"%02x",bmt_sum); if( ((bmt_ack+bmt_dath+bmt_datl)&0x7f)!=bmt_sum) strcat(szTemp2," SUM-ERROR"); } else sprintf(szTemp2,"--");
    strcat(szTemp,szTemp2);

    if(datth!=NULL) *datth=bmt_dath;
    if(dattl!=NULL) *dattl=bmt_datl;

    //ErrorScreen.add(szTemp);  // can be usefull for debug
    //MessageBox(NULL,szTemp,"debug",MB_OK);

    return 1;
}


int exchange(int board_adr, int op, int dath, int datl, int* datth, int* dattl, int en_ack, int en_sum)
{
    int a,b;

    if(serial.hCom==NULL) return 0;

    if(exchange2(board_adr,op,dath,datl,&a,&b,en_ack,en_sum)==0)
    {
        serial.close();
        mode=MODE_PRES;
        return 0;
    }

    if(datth!=NULL) *datth=a;
    if(dattl!=NULL) *dattl=b;

    return 1;
}

#ifdef KOKO
int main_old(int argc, char *argv[])
{
  int data,i,adr;
  char c;
  int op,dh,dl,enack,ensum;

  serial.init("COM2",19200);

  printf("\n\nx -- exit\na -- adress \nw / r -- write / read\ne / l -- ecrire / lire\ni / y -- echange op-dh-dl / echange op-dh-dl-enack-ensum\n>");

  do
  {
      if(c=='h') printf("\n\nx -- exit\na -- adress \nw / r -- write / read\ne / l -- ecrire / lire\ni / y -- echange op-dh-dl / echange op-dh-dl-enack-ensum\n>");
      scanf(" %c",&c);

      if(c=='w') { printf("\ntx-->0x"); scanf(" %x",&data); serial.write(data); }
      if(c=='r') { if(serial.read(&data)==0) printf("\nrx=nothing"); else printf("\nrx=0x%x",data); }
      if(c=='s') Sleep(1000);
      if(c=='a') {printf("\nadr-->0x"); scanf("%x",&adr);  exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);}
      if(c=='e') {printf("\ndat-->0x"); scanf("%x",&data); exchange(3,4,0,data&255,NULL,NULL,1,1);}
      if(c=='l') {                                         if(exchange(3,0,0,0,&dh,&dl,1,1)) printf(" --> rx=0x%x",dl); }
      if(c=='c') { for(i=0;i<100;i++) { Sleep(200);        exchange(3,0,0,0,NULL,NULL,1,1); printf("\n");} }
      if(c=='i') { printf("\nop dh dl-->"); scanf("%x",&op); scanf("%x",&dh); scanf("%x",&dl); exchange(3,op,dh,dl,NULL,NULL,1,1); }
      if(c=='y') { printf("\nop dh dl enack ensum -->"); scanf("%x",&op); scanf("%x",&dh); scanf("%x",&dl); scanf("%x",&enack); scanf("%x",&ensum); exchange(3,op,dh,dl,NULL,NULL,enack,ensum); }
      printf("\n");
  }
  while(c!='x');

  serial.close();

  return 0;
}
#endif //KOKO


int download_gra(void)
{
    int i;
    int adr,instr;
    int dath,datl;
    char szTemp[255];


    // 1. Verify if someting to load
    if(hex_gra_ind==0)
    {
        MessageBox(hwnd,"Error: Nothing to load, Compile your graphcet before !","progapi",MB_OK | MB_ICONERROR);
        return 0;
    }

    // 2. Open port
    serial.init(szConfigPort,19200);

    // 3. Stop API
    adr=0x67;
    exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
    exchange(3,4,0,0,NULL,NULL,1,1);

    // 4. Load graphcet
    for(i=0;i<hex_gra_ind;i=i++)
    {
        adr=def_ZG_START+i;

        instr=hex_gra[i];

        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,7,0x34,instr&255,NULL,NULL,1,1);
        exchange(3,3,0,0,&dath,&datl,1,1);

        if(dath!=0x34 || datl!=instr)
        {
            sprintf(szTemp,"Error: Cannot program adr 0x%04x write=%02x%02x read=%02x%02x",adr,0x34,instr,dath,datl);
            ErrorScreen.add(szTemp);
            MessageBox(hwnd, szTemp, "progapi", MB_OK | MB_ICONERROR);
            break;
        }
    }

    // 5. Reset and Start API
    adr=0x67;
    exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
    exchange(3,4,0,0xe0,NULL,NULL,1,1);  // set OUT.IN.RESET.0.0.0.0.0
    Sleep(100);
    exchange(3,4,0,0xd0,NULL,NULL,1,1);  // set OUT.IN.0.RUN.0.0.0.0

    // 6. Close port
    serial.close();

    ErrorScreen.clr();
    ErrorScreen.add("API programmed with SUCCESS");
    MessageBox(hwnd,"API programmed with SUCCESS", "progapi", MB_OK | MB_ICONINFORMATION);

    return 1;
}


void write_at_adr(int adr,int dat)
{
    exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
    exchange(3,4,(dat>>8)&255,dat&255,NULL,NULL,1,1);
}


void read_at_adr(int adr, int* dat)
{
    int dh,dl;

    exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
    exchange(3,0,0,0,&dh,&dl,1,1);
    *dat=((dh<<8)&0xff00)|(dl&0xff);
}






/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

        G U I    F U N C T I O N S   ( D R A W   &   A C T I O N S )

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/






/*****************************************************************************/
/* USEFULL GRAPHICAL FUNCTIONS                                               */
/*****************************************************************************/


void _TextOut(int x,int y,char txt[])
{
    TextOut(hdc,x,y,txt,strlen(txt));
}


void draw_clear(void)
{
    SelectObject(hdc,My_Pen_White);
    SelectObject(hdc,My_Brush_White);
    Rectangle(hdc,0,0,2000,1000);
}


char name[16][20]={"","","","","","","","","","","","","","","",""};
int adr[16]={       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int dat[16]={       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
char suppl[16]={    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int  on[16]={       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int  tx_data=0;
int  rx_data=-1;


void draw_rs232(void)
{
    int j,i;
    char ch[255];
    static int cpt=0;

    serial.init(szConfigPort,19200);

    if((cpt++)==40) { cpt=0; draw_clear(); }

    SelectObject(hdc,My_Pen_Presentation);
    SelectObject(hdc,My_Brush_Presentation);
    Rectangle(hdc,20,20,430,40);
    for(i=0;i<16;i++) {MoveToEx(hdc,20,40+20*i,NULL);LineTo(hdc,430,40+20*i);}
    MoveToEx(hdc,120,20,NULL);LineTo(hdc,120,40);
    MoveToEx(hdc,170,20,NULL);LineTo(hdc,170,40);
    MoveToEx(hdc,220,40,NULL);LineTo(hdc,220,40);
    MoveToEx(hdc,270,40,NULL);LineTo(hdc,270,40);
    MoveToEx(hdc,370,20,NULL);LineTo(hdc,370,40);
    MoveToEx(hdc,390,20,NULL);LineTo(hdc,390,40);
    MoveToEx(hdc,410,20,NULL);LineTo(hdc,410,40);

    Rectangle(hdc,520, 20,580, 40);
    Rectangle(hdc,520, 40,580, 60);

//    Rectangle(hdc,450, 80,550,100); Rectangle(hdc,550, 80,580,100);
//    Rectangle(hdc,450,100,550,120); Rectangle(hdc,550,100,580,120);

    SelectObject(hdc,My_Font);
    SetBkMode(hdc,TRANSPARENT);
    SetTextColor(hdc,RGB_PRESENTATION_TXT);
    _TextOut( 30, 25,"name");
    _TextOut(130, 25,"adr");
    _TextOut(180, 25,"data (hex,dec,bin)");
    _TextOut(375, 25,"R");
    _TextOut(395, 25,"W");
    _TextOut(415, 25,"+");

    _TextOut(530, 25,"LD cfg");
    _TextOut(530, 45,"SV cfg");
//    _TextOut(555, 85,"TX");
//    _TextOut(555,105,"RX");

//    sprintf(ch,"%x%x",(tx_data>>4)&15,tx_data&15); _TextOut(460, 80, ch);
//    if(rx_data==-1) strcpy(ch,"NOT");
//    else sprintf(ch,"%x%x",(rx_data>>4)&15,rx_data&15);
//    _TextOut(460,100, ch);

    _TextOut(100,400,"mode (col +)");  _TextOut(200,400,"X = disable");
                                       _TextOut(200,415,"space = enable");
                                       _TextOut(200,430,"A = continuous read");
                                       _TextOut(200,445,"B = continuous read and graph");
                                       _TextOut(200,460,"D = direct write");
    _TextOut(100,480,"read  (col R)");
    _TextOut(100,500,"write (col W)");

    for(i=0;i<16;i++)
    {
        Rectangle(hdc,20,40+i*20,430,60+i*20);

        MoveToEx(hdc,120,40+i*20,NULL);LineTo(hdc,120,60+i*20);
        MoveToEx(hdc,170,40+i*20,NULL);LineTo(hdc,170,60+i*20);
        MoveToEx(hdc,220,40+i*20,NULL);LineTo(hdc,220,60+i*20);
        MoveToEx(hdc,270,40+i*20,NULL);LineTo(hdc,270,60+i*20);
        MoveToEx(hdc,370,40+i*20,NULL);LineTo(hdc,370,60+i*20);
        MoveToEx(hdc,390,40+i*20,NULL);LineTo(hdc,390,60+i*20);
        MoveToEx(hdc,410,40+i*20,NULL);LineTo(hdc,410,60+i*20);


        if(on[i])
        {
            sprintf(ch,"%s"  , name[i]                ); _TextOut( 30,45+20*i,ch);
            sprintf(ch,"%x%x",(adr[i]>>4)&15,adr[i]&15); _TextOut(130,45+20*i,ch);
            sprintf(ch,"%x%x",(dat[i]>>4)&15,dat[i]&15); _TextOut(180,45+20*i,ch);
            sprintf(ch,"%3d" , dat[i]                 ); _TextOut(230,45+20*i,ch);
            ch[0]='\0';
            for(j=0;j<8;j++)
            {
                if(dat[i]&(1<<j)) strcpy(ch,"1"); else strcpy(ch,"0");
                _TextOut(280+10*(7-j),45+20*i,ch);
            }
            if     (suppl[i]=='A') { _TextOut(415,45+20*i,"A"); read_at_adr(adr[i],&dat[i]); }
            else if(suppl[i]=='B') { _TextOut(415,45+20*i,"B"); read_at_adr(adr[i],&dat[i]); }
            else if(suppl[i]=='D') { _TextOut(415,45+20*i,"D"); write_at_adr(adr[i],dat[i]); }
            else if(suppl[i]=='P')   _TextOut(415,45+20*i,"P");
        }

        if(on[i]==0) _TextOut(415,45+20*i,"X");
    }

    j=0;
    for(i=0;i<16;i++) if(on[i])
    {
        if(suppl[i]=='B')
        {
            SelectObject(hdc,My_Pen_White);
            SelectObject(hdc,My_Brush_White);
            Rectangle(hdc,450+30*j,140,480+30*j,360);

            SelectObject(hdc,My_Pen_Presentation);
            SelectObject(hdc,My_Brush_Presentation);

            sprintf(ch,"%x%x",(adr[i]>>4)&15,adr[i]&15); _TextOut(450+30*j,325,ch);
            sprintf(ch,"%x%x",(dat[i]>>4)&15,dat[i]&15); _TextOut(450+30*j,345,ch);

            MoveToEx(hdc,460+30*j,140,NULL);
            LineTo(hdc,460+30*j,140+(255*2)/3);LineTo(hdc,470+30*j,140+(255*2)/3);
            LineTo(hdc,470+30*j,140          );LineTo(hdc,460+30*j,140);
            Rectangle(hdc,460+30*j,140+(255*2)/3,470+30*j,140+(255*2)/3-(dat[i]*2)/3);

            j++;
            if(j==5) break;
        }
    }

    serial.close();
}


BOOL load_monitor_file(void)
{
   OPENFILENAME ofn;
   FILE* pf;
   int i;
   int ok;
   char ch[255];
   char szFileName[255];

   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFilter = "All Files (*.*)\0*.*\0\0";
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrDefExt = "";


    ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

    if(GetOpenFileName(&ofn)==0)
    {
       MessageBox(hwnd, "Cannot open the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);

       return FALSE;
    }

    if((pf=fopen(szFileName,"rt"))==NULL)
    {
        MessageBox(hwnd, "Cannot open the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    ok=1;
    fscanf(pf,"%s",ch); if(stricmp(ch,"MRC"    )!=0) ok=0;
    fscanf(pf,"%s",ch); if(stricmp(ch,"MONITOR")!=0) ok=0;
    fscanf(pf,"%s",ch); if(stricmp(ch,"FILE"   )!=0) ok=0;
    if(ok==0)
    {
        MessageBox(hwnd, "Specfied file is not a MRC MONITOR FILE.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    for(i=0;i<16;i++)
    {
        fscanf(pf," %s",ch       ); strcpy(name[i],&ch[1]);
        fscanf(pf," %x",&adr[i]  );
        fscanf(pf," %x",&dat[i]  );
        fscanf(pf," %s",ch       ); suppl[i]=ch[1];
        fscanf(pf," %d",&on[i]   );
    }

    fclose(pf);
    /* ... */

    return TRUE;

}


BOOL save_monitor_file(void)
{
    OPENFILENAME ofn;
    FILE* pf;
    int i;
   char szFileName[255];

    ZeroMemory(&ofn, sizeof(ofn));
    szFileName[0] = 0;

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = "All Files (*.*)\0*.*\0\0";
    ofn.lpstrFile = szFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "";

    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;

    if(GetSaveFileName(&ofn)==0)
    {
        MessageBox(hwnd, "Cannot save in the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    if((pf=fopen(szFileName,"wt"))==NULL)
    {
        MessageBox(hwnd, "Cannot create or open the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    fprintf(pf,"MRC MONITOR FILE");

    for(i=0;i<16;i++) fprintf(pf,"\n_%s %x %x _%c %d",name[i],adr[i],dat[i],suppl[i],on[i]);

    fclose(pf);

    return TRUE;
}


#define SEL_NO     0
#define SEL_ADRHEX 1
#define SEL_DATHEX 2
#define SEL_DATDEC 3
#define SEL_SUPPL  4
#define SEL_NAME   5
#define SEL_TX     6
void action_rs232(UINT action)
{
    int i;
    static int sel_type;
    static int sel_i=0;
    int nb;
    char ch[255];


    serial.init(szConfigPort,19200);

    if(action==WM_LBUTTONDOWN)
    {
        sel_type=SEL_NO;

        if(x_mouse>520 && x_mouse<580)
        {
            if(y_mouse>20 && y_mouse<40) load_monitor_file();
            if(y_mouse>40 && y_mouse<60) save_monitor_file();
        }
/*
        if(x_mouse>550 && x_mouse<580)   // direct send / receive
        {
            if(y_mouse> 80 && y_mouse<100) serial.write(tx_data);
            if(y_mouse>100 && y_mouse<120) if(serial.read(&rx_data)==FALSE) rx_data=-1;;
        }
*/
        if(x_mouse>370 && x_mouse<390 && y_mouse>40 && y_mouse<(40+16*20))  // read
        {
            i=(y_mouse-40)/20;
            if(on[i]) if(adr[i]!=-1) read_at_adr(adr[i],&dat[i]);
        }

        if(x_mouse>390 && x_mouse<410 && y_mouse>40 && y_mouse<(40+16*20))  // write
        {
            i=(y_mouse-40)/20;
            if(on[i]) if(adr[i]!=-1) write_at_adr(adr[i],dat[i]);
        }

        if(x_mouse>410 && x_mouse<430 && y_mouse>40 && y_mouse<(40+16*20))
        {
            sel_i=(y_mouse-40)/20;
            sel_type=SEL_SUPPL;
        }

        if(x_mouse>120 && x_mouse<170 && y_mouse>40 && y_mouse<(40+16*20))
        {
            i=(y_mouse-40)/20;
            if(on[i]) { sel_type=SEL_ADRHEX; sel_i=i; }
        }

        if(x_mouse>170 && x_mouse<220 && y_mouse>40 && y_mouse<(40+16*20))
        {
            i=(y_mouse-40)/20;
            if(on[i]) { sel_type=SEL_DATHEX; sel_i=i; }
        }

        if(x_mouse>220 && x_mouse<270 && y_mouse>40 && y_mouse<(40+16*20))
        {
            i=(y_mouse-40)/20;
            if(on[i]) { sel_type=SEL_DATDEC; sel_i=i; }
        }

        if(x_mouse>20 && x_mouse<120 && y_mouse>40 && y_mouse<(40+16*20))
        {
            i=(y_mouse-40)/20;
            if(on[i])  { sel_type=SEL_NAME; sel_i=i; }
        }

        if(x_mouse>280 && x_mouse<360 && y_mouse>40 && y_mouse<(40+16*20))
        {
            i=(y_mouse-40)/20;
            if(on[i]) dat[i]^=1<<(7-(x_mouse-280)/10);
        }

        if(x_mouse>450 && x_mouse<550 && y_mouse>80 && y_mouse<100)
        {
            sel_type=SEL_TX;
        }
    }

    if(action==WM_CHAR)
    {
        nb=-1;
        if(key_char>='0' && key_char<='9') nb=key_char-'0';
        if(key_char>='a' && key_char<='f') nb=key_char-'a'+10;
        if(key_char>='A' && key_char<='F') nb=key_char-'A'+10;

        if(sel_type==SEL_SUPPL) if(key_char=='x' || key_char=='X') on[sel_i]=0; //^=1
        if(sel_type==SEL_SUPPL) if(key_char==' ' || key_char==' ') on[sel_i]=1;

        if(sel_type==SEL_TX) tx_data=((tx_data<<4)&0xff)+nb;

        if(on[sel_i])
        {
            if(sel_type==SEL_SUPPL) if(key_char=='a' || key_char=='A') suppl[sel_i]='A';
            if(sel_type==SEL_SUPPL) if(key_char=='b' || key_char=='B') suppl[sel_i]='B';
            if(sel_type==SEL_SUPPL) if(key_char=='d' || key_char=='D') suppl[sel_i]='D';
            if(sel_type==SEL_SUPPL) if(key_char=='p' || key_char=='P') suppl[sel_i]=' '; //P not used for the moment
            if(sel_type==SEL_SUPPL) if(key_char==' '                 ) suppl[sel_i]=' ';

            if(sel_type==SEL_NAME  )
            {
                if(key_char==' ') name[sel_i][0]='\0';
                else if(strlen(name[sel_i])<10)
                {
                    sprintf(ch,"%c",key_char);
                    strcat(name[sel_i],ch);
                }
            }

            if(nb!=-1)
            {
                if(sel_type==SEL_ADRHEX) adr[sel_i]=((adr[sel_i]<<4)&0xff)+nb;
                if(sel_type==SEL_DATHEX) dat[sel_i]=((dat[sel_i]<<4)&0xff)+nb;
                if(sel_type==SEL_DATDEC) { dat[sel_i]=(dat[sel_i]*10)+nb; dat[sel_i]%=1000; if(dat[sel_i]>255) dat[sel_i]%=100; }
            }
        }
    }

    serial.close();
}


void draw_vert(int x, int y, char szStr[])
{
    int i;
    int x0=100;
    int y0=100;
    int d=20;
    char szTemp[10];

    for(i=0;i<strlen(szStr);i++) { sprintf(szTemp,"%c",szStr[i]); _TextOut(x0+x*d+3+2,y0+y*d+i*12+3,szTemp); }
}


int cpt_rs232io=0;
int state_run=1;
int see_ports_de=1;


void draw_rs232io(void)
{
    static int cpt=0;
    int adr,dh,dl,i,j;
    int zbpa, zbpb, zbpc, zbpd, zbpe, zbpcir, can0, can1, can2, can3, can5, horoh, horol, sec;
    int x0,y0,d;
    char szTemp[255];

    cpt_rs232io++;

    serial.init(szConfigPort,19200);

    adr=0x3b; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); zbpa=dl;
    adr=0x3a; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); zbpb=dl;
    adr=0x39; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); zbpc=dl;
    adr=0x38; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); zbpd=dl;
    adr=0x37; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); zbpe=dl;
    adr=0x36; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); zbpcir=dl;

    adr=0xd4; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); can0=dl;
    adr=0xd5; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); can1=dl;
    adr=0xd6; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); can2=dl;
    adr=0xd7; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); can3=dl;
    adr=0xd8; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); can5=dl;

    adr=0xec; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); horoh=dl;
    adr=0xed; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); horol=dl;
    adr=0x6a; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); exchange(3,0,0,0,&dh,&dl,1,1); sec=dl&63; //sec=60-sec;

    serial.close();

    SelectObject(hdc,My_Font);
    SetBkMode(hdc,TRANSPARENT);
    SetTextColor(hdc,RGB_PRESENTATION_TXT);

    x0=100;y0=100;d=20;

    if((cpt_rs232io%30)==1)
    {
        SelectObject(hdc,My_Brush_Presentation);
        Rectangle(hdc,0,0,1240,1024);

        SelectObject(hdc,My_Brush_Blue);
        Rectangle(hdc,x0,y0,x0+16*d,y0+d);
        Rectangle(hdc,x0,y0+5*d,x0+8*d,y0+6*d);
        Rectangle(hdc,x0+11*d,y0+5*d,x0+21*d,y0+6*d);
        Rectangle(hdc,x0+13*d,y0+4*d,x0+19*d,y0+5*d);

        SelectObject(hdc,My_Brush_White);
        Rectangle(hdc,x0,y0+d,x0+23*d,y0+5*d);

        SelectObject(hdc,My_Brush_BlueL);
        Rectangle(hdc,x0+16*d,y0,x0+23*d,y0+d);
        Rectangle(hdc,x0+8*d,y0+5*d,x0+11*d,y0+6*d);
        Rectangle(hdc,x0+21*d,y0+5*d,x0+23*d,y0+6*d);
    }

    SelectObject(hdc,My_Brush_Grey);
    Rectangle(hdc,490,140,550,160); _TextOut(493,143,"RESET");
    Rectangle(hdc,490,170,550,190);
    if(state_run==0) _TextOut(493,173,"START"); else _TextOut(493,173,"STOP");

    SelectObject(hdc,My_Brush_Grey);
    Rectangle(hdc,x0+10*d,y0+2*d,x0+12*d,y0+3*d);
    _TextOut(x0+10*d+3,y0+2*d+3,"UPDT");

    Rectangle(hdc,x0+10*d,170,x0+12*d,190);
    _TextOut(x0+10*d+3,173,"D/E");

    SelectObject(hdc,My_Brush_White);
    Rectangle(hdc,x0+13*d,y0+2*d,x0+18*d+5,y0+3*d);
    switch((horoh>>5)&7)
    {
        case 0: sprintf(szTemp,"xxx xx:xx:xx"); break;
        case 1: sprintf(szTemp,"lun %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
        case 2: sprintf(szTemp,"mar %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
        case 3: sprintf(szTemp,"mer %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
        case 4: sprintf(szTemp,"jeu %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
        case 5: sprintf(szTemp,"ven %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
        case 6: sprintf(szTemp,"sam %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
        case 7: sprintf(szTemp,"dim %02d:%02d:%02d",horoh&0x1f,horol,sec); break;
    }
    _TextOut(x0+13*d+3,y0+2*d+3,szTemp);

     if(zbpb&(1<<7)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,    x0+3,y0+3,    x0+17,y0+17);
     if(zbpb&(1<<6)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,1*d+x0+3,y0+3,1*d+x0+17,y0+17);
     if(zbpb&(1<<5)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,2*d+x0+3,y0+3,2*d+x0+17,y0+17);
     if(zbpb&(1<<4)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,3*d+x0+3,y0+3,3*d+x0+17,y0+17);
     if(zbpb&(1<<3)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,4*d+x0+3,y0+3,4*d+x0+17,y0+17);
     if(zbpb&(1<<2)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,5*d+x0+3,y0+3,5*d+x0+17,y0+17);
     if(zbpb&(1<<1)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,6*d+x0+3,y0+3,6*d+x0+17,y0+17);
     if(zbpb&(1<<0)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,7*d+x0+3,y0+3,7*d+x0+17,y0+17);

     if(see_ports_de)
     {
     if(zbpd&(1<<7)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,16*d+x0+3,y0+3,16*d+x0+17,y0+17);
     if(zbpd&(1<<6)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,17*d+x0+3,y0+3,17*d+x0+17,y0+17);
     if(zbpd&(1<<5)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,18*d+x0+3,y0+3,18*d+x0+17,y0+17);
     if(zbpd&(1<<4)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,19*d+x0+3,y0+3,19*d+x0+17,y0+17);
     if(zbpd&(1<<3)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,21*d+x0+3,y0+3,21*d+x0+17,y0+17);
     if(zbpd&(1<<2)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,22*d+x0+3,y0+3,22*d+x0+17,y0+17);
     }

     if(zbpa&(1<<0)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,0*d+x0+3,5*d+y0+3,0*d+x0+17,5*d+y0+17);
     if(zbpa&(1<<1)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,1*d+x0+3,5*d+y0+3,1*d+x0+17,5*d+y0+17);
     if(zbpa&(1<<2)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,2*d+x0+3,5*d+y0+3,2*d+x0+17,5*d+y0+17);
     if(zbpa&(1<<3)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,3*d+x0+3,5*d+y0+3,3*d+x0+17,5*d+y0+17);
     if(zbpa&(1<<5)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,5*d+x0+3,5*d+y0+3,5*d+x0+17,5*d+y0+17);

     if(see_ports_de)
     {
     if(zbpe&(1<<0)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,8*d+x0+3,5*d+y0+3,8*d+x0+17,5*d+y0+17);
     if(zbpe&(1<<1)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,9*d+x0+3,5*d+y0+3,9*d+x0+17,5*d+y0+17);
     if(zbpe&(1<<2)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,10*d+x0+3,5*d+y0+3,10*d+x0+17,5*d+y0+17);
     }

     if(zbpc&(1<<0)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,13*d+x0+3,5*d+y0+3,13*d+x0+17,5*d+y0+17);
     if(zbpc&(1<<2)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,15*d+x0+3,5*d+y0+3,15*d+x0+17,5*d+y0+17);
     if(zbpc&(1<<3)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,16*d+x0+3,5*d+y0+3,16*d+x0+17,5*d+y0+17);
     if(zbpc&(1<<4)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,17*d+x0+3,5*d+y0+3,17*d+x0+17,5*d+y0+17);
     if(zbpc&(1<<5)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,18*d+x0+3,5*d+y0+3,18*d+x0+17,5*d+y0+17);

     if(zbpcir&(1<<0)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,13*d+x0+3,4*d+y0+3,13*d+x0+17,4*d+y0+17);
     if(zbpcir&(1<<2)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,15*d+x0+3,4*d+y0+3,15*d+x0+17,4*d+y0+17);
     if(zbpcir&(1<<3)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,16*d+x0+3,4*d+y0+3,16*d+x0+17,4*d+y0+17);
     if(zbpcir&(1<<4)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,17*d+x0+3,4*d+y0+3,17*d+x0+17,4*d+y0+17);
     if(zbpcir&(1<<5)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,18*d+x0+3,4*d+y0+3,18*d+x0+17,4*d+y0+17);

     if(see_ports_de)
     {
     if(zbpd&(1<<0)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,21*d+x0+3,5*d+y0+3,21*d+x0+17,5*d+y0+17);
     if(zbpd&(1<<1)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red); Rectangle(hdc,22*d+x0+3,5*d+y0+3,22*d+x0+17,5*d+y0+17);
     }

     SelectObject(hdc,My_Brush_Green); Rectangle(hdc,0*d+x0+3,5*d+y0-3   ,0*d+x0+17,5*d+y0-3-can0/4);
     SelectObject(hdc,My_Brush_White); Rectangle(hdc,0*d+x0+3,5*d+y0-3-63,0*d+x0+17,5*d+y0-3-can0/4); sprintf(szTemp,"%03d",can0); draw_vert(0,2,szTemp);
     SelectObject(hdc,My_Brush_Green); Rectangle(hdc,1*d+x0+3,5*d+y0-3   ,1*d+x0+17,5*d+y0-3-can1/4);
     SelectObject(hdc,My_Brush_White); Rectangle(hdc,1*d+x0+3,5*d+y0-3-63,1*d+x0+17,5*d+y0-3-can1/4); sprintf(szTemp,"%03d",can1); draw_vert(1,2,szTemp);
     SelectObject(hdc,My_Brush_Green); Rectangle(hdc,2*d+x0+3,5*d+y0-3   ,2*d+x0+17,5*d+y0-3-can2/4);
     SelectObject(hdc,My_Brush_White); Rectangle(hdc,2*d+x0+3,5*d+y0-3-63,2*d+x0+17,5*d+y0-3-can2/4); sprintf(szTemp,"%03d",can2); draw_vert(2,2,szTemp);
     SelectObject(hdc,My_Brush_Green); Rectangle(hdc,3*d+x0+3,5*d+y0-3   ,3*d+x0+17,5*d+y0-3-can3/4);
     SelectObject(hdc,My_Brush_White); Rectangle(hdc,3*d+x0+3,5*d+y0-3-63,3*d+x0+17,5*d+y0-3-can3/4); sprintf(szTemp,"%03d",can3); draw_vert(3,2,szTemp);
     SelectObject(hdc,My_Brush_Green); Rectangle(hdc,5*d+x0+3,5*d+y0-3   ,5*d+x0+17,5*d+y0-3-can5/4);
     SelectObject(hdc,My_Brush_White); Rectangle(hdc,5*d+x0+3,5*d+y0-3-63,5*d+x0+17,5*d+y0-3-can5/4); sprintf(szTemp,"%03d",can5); draw_vert(5,2,szTemp);

     draw_vert( 0,-2,"OB7"); draw_vert( 1,-2,"OB6"); draw_vert( 2,-2,"OB5"); draw_vert( 3,-2,"OB4"); draw_vert( 4,-2,"OB3"); draw_vert( 5,-2,"OB2"); draw_vert( 6,-2,"OB1"); draw_vert( 7,-2,"OB0");
     if(see_ports_de)
     {
     draw_vert(16,-2,"OD7"); draw_vert(17,-2,"OD6"); draw_vert(18,-2,"OD5"); draw_vert(19,-2,"OD4"); draw_vert(21,-2,"OD3"); draw_vert(22,-2,"OD2");
     }

     draw_vert( 0,6,"IA0"); draw_vert( 1,6,"IA1"); draw_vert( 2,6,"IA2"); draw_vert( 3,6,"IA3"); draw_vert( 5,6,"IA5");
     if(see_ports_de)
     {
     draw_vert( 8,6,"IE0"); draw_vert( 9,6,"IE1"); draw_vert(10,6,"IE2");
     }
     draw_vert(13,6,"IC0"); draw_vert(15,6,"IC2"); draw_vert(16,6,"IC3"); draw_vert(17,6,"IC4"); draw_vert(18,6,"IC5");
     if(see_ports_de)
     {
     draw_vert(21,6,"ID0"); draw_vert(22,6,"ID1");
     }

     //   Rectangle(hdc,190,20*j+10,230,20*j+10+20);
     //   sprintf(szTemp,"%02x",dl);  _TextOut(200,20*j+10,szTemp);

}


void action_rs232io(UINT action)
{
    SYSTEMTIME lpSystemTime;
    int curr_hour,curr_min,curr_sec,curr_day;
    char szTemp[255];


    serial.init(szConfigPort,19200);

    if(action==WM_LBUTTONDOWN)
    {
        if(x_mouse>490 && x_mouse<550)
        {
            // 0x67:     OUT.IN.RESET.RUN.0.0.0.0
            if(y_mouse>140 && y_mouse<160) { write_at_adr(0x67,0xe0); Sleep(100); write_at_adr(0x67,0xd0); state_run=1;}
            if(y_mouse>170 && y_mouse<190) { if(state_run) { write_at_adr(0x67,0xc0); state_run=0; } else { write_at_adr(0x67,0xd0); state_run=1; } }
        }

        if(x_mouse>=100+10*20 && x_mouse<=100+12*20)
        {
            if(y_mouse>170 && y_mouse<190)
            {
                see_ports_de^=1;
                cpt_rs232io=0;
            }

            if(y_mouse>140 && y_mouse<160 )
            {
                GetLocalTime(&lpSystemTime);
                curr_day =(int)lpSystemTime.wDayOfWeek;
                curr_hour=(int)lpSystemTime.wHour;
                curr_min =(int)lpSystemTime.wMinute;
                curr_sec =(int)lpSystemTime.wSecond;

                if(curr_day==0) curr_day=7;   //dim=0 lun=1 ... sam=6 --> lun=1 sam=6 ... dim=7
                write_at_adr(0xec,(curr_day<<5)+curr_hour);
                write_at_adr(0xed,curr_min);
                write_at_adr(0x6a,/*60-*/curr_sec);

                //attention: l'utilisation de MsgBox passe la main a la boucle ce qui peut poser des pb d'ouverture de port par exemple
                //sprintf(szTemp,"day=%d hour=%d min=%d sec=%d (day_hour=%0x)",curr_day,curr_hour,curr_min,curr_sec,(curr_day<<5)+curr_hour);
                //MessageBox(hwnd,szTemp,"debug",MB_OK);

            }
        }
    }

    serial.close();
}


void draw_rs232zbzv_old(void)
{
    int adr,dh,dl,i,j;
    char szTemp[255];

    serial.init(szConfigPort,19200);

    //adr=0x68; //cpt330
    //adr=0x36; //ir

    for(j=0;j<32;j++)
    {
        adr=0x20+j;
        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,0,0,0,&dh,&dl,1,1);
        for(i=0; i<8; i++)
        {
            if(dl&(128>>i)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red);
            Rectangle(hdc,i*15+10,j*15+10,i*15+20,j*15+20);
        }
    }

    SelectObject(hdc,My_Brush_Green);
    SelectObject(hdc,My_Font);
    SetBkMode(hdc,TRANSPARENT);
    SetTextColor(hdc,RGB_PRESENTATION_TXT);
    for(j=0;j<24;j++)
    {
        adr=0xc0+2*j;
        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,0,0,0,&dh,&dl,1,1);
        Rectangle(hdc,190,20*j+10,230,20*j+10+20);
        sprintf(szTemp,"%02x",dl);  _TextOut(200,20*j+10,szTemp);
        adr++;
        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,0,0,0,&dh,&dl,1,1);
        Rectangle(hdc,230,20*j+10,270,20*j+10+20);
        sprintf(szTemp,"%02x",dl);  _TextOut(240,20*j+10,szTemp);
    }

    serial.close();
}

void draw_rs232zbzv(void)
{
    int adr,dh,dl,dl0,i,j;
    char szTemp[255];

    serial.init(szConfigPort,19200);

    //adr=0x68; //cpt330
    //adr=0x36; //ir

    SelectObject(hdc,My_Font);
    SetBkMode(hdc,TRANSPARENT);
    SetTextColor(hdc,RGB_PRESENTATION_TXT);

    // ZB
    for(j=0;j<32;j++)
    {
        adr=0x20+j;
        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,0,0,0,&dh,&dl,1,1);
        for(i=0; i<8; i++)
        {
            var_name_get(8*j+(7-i),VARTYPE_ZB,szTemp);
            szTemp[7]='\0';
            if(dl&(128>>i)) SelectObject(hdc,My_Brush_Green); else SelectObject(hdc,My_Brush_Red);
            Rectangle(hdc,i*55+10,j*18+10,i*55+10+50,j*18+10+15);
            _TextOut(i*55+12,j*18+10,szTemp);
        }
    }

    // ZV
    SelectObject(hdc,My_Brush_Green);
    for(j=0;j<24;j++)
    {
        int x0=470;

        adr=0xc0+2*j;
        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,0,0,0,&dh,&dl0,1,1);
        adr++;
        exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
        exchange(3,0,0,0,&dh,&dl,1,1);

        var_name_get(2*j,VARTYPE_ZV16,szTemp);
        szTemp[7]='\0';
        _TextOut(x0,24*j+10,szTemp);

        Rectangle(hdc,x0+50,24*j+10,x0+50+70,24*j+10+20);
        sprintf(szTemp,"%5d",(dl0<<8)+dl);  _TextOut(x0+50+5,24*j+10+2,szTemp);

        var_name_get(2*j,VARTYPE_ZV8,szTemp);
        szTemp[7]='\0';
        _TextOut(x0+150,24*j+10,szTemp);

        Rectangle(hdc,x0+200,24*j+10,x0+200+45,24*j+10+20);
        sprintf(szTemp,"%3d",dl0);  _TextOut(x0+200+5,24*j+10+2,szTemp);

        var_name_get(2*j+1,VARTYPE_ZV8,szTemp);
        szTemp[7]='\0';
        _TextOut(x0+300,24*j+10,szTemp);

        Rectangle(hdc,x0+250,24*j+10,x0+250+45,24*j+10+20);
        sprintf(szTemp,"%3d",dl);  _TextOut(x0+250+5,24*j+10+2,szTemp);
    }

    serial.close();
}




int cpt_graphic=0;
int trace_analogique[5][800];
int trace_digital[10][800];
//int adr_ana[5]= {0xc0+20,0xc0+21,0xc0+22,0xc0+23,0xc0+24} ;
//int adr_dig[10][2]= { {0x20+25,0}, {0x20+25,2}, {0x20+26,0} , {0x20+26,1}, {0x20+26,2}, {0x20+26,3}, {0x20+26,4}, {0x20+26,5}, {0x20+26,6}, {0x20+26,7} };
int adr_ana[5]= { -1,-1,-1,-1,-1 } ;
int adr_dig[10][2]= { {-1,0}, {-1,0}, {-1,0}, {-1,0}, {-1,0}, {-1,0}, {-1,0}, {-1,0}, {-1,0}, {-1,0} };
int graphic_mode=0;
int cpt_wait=0;               // compteur pouir diviser les 100ms
char graphic_name[15][10]={"","","","","","","","","","","","","","",""};
int  graphic_selected=-1;


int atoh(char* str)
{
    int nb=0;
    char c;
    char* pt;

    pt=str;

    while(c=*pt++)
    {
        if     (c>='0' && c<='9') nb=16*nb+c-'0';
        else if(c>='a' && c<='f') nb=16*nb+c-'a'+10;
        else if(c>='A' && c<='F') nb=16*nb+c-'A'+10;
        else break;
    }


    return nb;
}


BOOL graphic_load(void)
{
   OPENFILENAME ofn;
   FILE* pf;
   int i;
   char ch[255];
   char szFileName[255];
   int adr,bit;
   char* pt;
   int val,type;


   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFilter = "All Files (*.*)\0*.*\0\0";
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrDefExt = "";


    ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

    if(GetOpenFileName(&ofn)==0)
    {
       MessageBox(hwnd, "Cannot open the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);

       return FALSE;
    }

    if((pf=fopen(szFileName,"rt"))==NULL)
    {
        MessageBox(hwnd, "Cannot open the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    fscanf(pf,"%s",ch);
    if(stricmp(ch,"Progapi_2004_Graphic_Config_File" )!=0)
    {
        MessageBox(hwnd, "Specfied file is not a Progapi_2004_Graphic_Config_File", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    for(i=0;i<15;i++)
    {
        fscanf(pf," %s",ch);

        strcpy(graphic_name[i],&ch[1]);
        strcpy(ch,graphic_name[i]);

        if(i<5)
        {
            adr=-1;
            if(ch[0]=='0' && (ch[1]=='x' || ch[1]=='X') ) adr=atoh(&ch[2]);
            if(ch[0]>='0' && ch[0]<='9') adr=atoi(ch);
            if(var_adr_get(ch,&val,&type)) if(type==VARTYPE_ZV8) adr=0xc0+val;
            adr_ana[i]=adr;
        }

        if(i>=5)
        {
            adr=-1,bit=0;
            if((pt=strstr(ch,"."))!=NULL) if(ch[0]=='0' && (ch[1]=='x' || ch[1]=='X') ) { adr=atoh(&ch[2]); bit=atoi(pt+1); }
            if((pt=strstr(ch,"."))!=NULL) if(ch[0]>='0' &&  ch[0]<='9')                 { adr=atoi(ch);     bit=atoi(pt+1); }
            if(var_adr_get(ch,&val,&type)) if(type==VARTYPE_ZB)                         { adr=0x20+val/8;   bit=val%8;      }
            adr_dig[i-5][0]=adr; adr_dig[i-5][1]=bit;
        }
    }

    fclose(pf);

    return TRUE;
}


BOOL graphic_save(void)
{
    OPENFILENAME ofn;
    FILE* pf;
    int i;
   char szFileName[255];

    ZeroMemory(&ofn, sizeof(ofn));
    szFileName[0] = 0;

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = "All Files (*.*)\0*.*\0\0";
    ofn.lpstrFile = szFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "";

    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;

    if(GetSaveFileName(&ofn)==0)
    {
        MessageBox(hwnd, "Cannot save in the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    if((pf=fopen(szFileName,"wt"))==NULL)
    {
        MessageBox(hwnd, "Cannot create or open the specified file.", "progapi",MB_OK | MB_ICONEXCLAMATION);
        return FALSE;
    }

    fprintf(pf,"Progapi_2004_Graphic_Config_File");

    for(i=0;i<15;i++) fprintf(pf,"\n_%s",graphic_name[i]);

    fclose(pf);

    return TRUE;
}


void draw_graphic(void)
{
    int adr,dh,dl,i,j,k,j2;   // pour les bpoucles
    char szTemp[255];         // chaine temporaire
    int ya=300;               // y bas du cadran analogique
    int yd=330;               // y haut du cadran numerique
    int capt;                 // sert a ne pas capturer les doublons
    int capt_one,capt_all_ana,capt_all_dig,draw_all,draw_one,inc; // ordres de capture et d'affichage


    // 1. Creation des ordres de capture et d'affichage suivant le mode courant

    capt_one=0; capt_all_ana=0; capt_all_dig=0; draw_all=0; draw_one=0; inc=0;

    if(graphic_mode==0)                       {             if((cpt_wait%50)==0) draw_all=1;                         }
    if(graphic_mode==1)                       { capt_one=1; if((cpt_wait%50)==0) draw_all=1; else draw_one=1; inc=1; }
    if(graphic_mode==2) if((cpt_wait%2)==0)   { capt_one=1; if((cpt_wait%50)==0) draw_all=1; else draw_one=1; inc=1; }
    if(graphic_mode==3) if((cpt_wait%5)==0)   { capt_one=1; if((cpt_wait%50)==0) draw_all=1; else draw_one=1; inc=1; }
    if(graphic_mode==4) if((cpt_wait%10)==0)  { capt_one=1; if((cpt_wait%50)==0) draw_all=1; else draw_one=1; inc=1; }
    if(graphic_mode==5) if((cpt_wait%20)==0)  { capt_one=1; if((cpt_wait%50)==0) draw_all=1; else draw_one=1; inc=1; }
    if(graphic_mode==6) if((cpt_wait%50)==0)  { capt_one=1;                      draw_all=1;                  inc=1; }
    if(graphic_mode==7) if((cpt_wait%100)==0) { capt_one=1;                      draw_all=1;                  inc=1; }
    if(graphic_mode==80)                      { capt_all_ana=1;                  draw_all=1;                         }
    if(graphic_mode==90)                      { capt_all_dig=1;                  draw_all=1;                         }
    if(graphic_mode==8)                       { /*graphic_mode=80;*/             draw_all=1;                         } // to green rectangle
    if(graphic_mode==9)                       { /*graphic_mode=90;*/             draw_all=1;                         } // to green rectangle
    if(graphic_mode==10)                      {                                  draw_all=1;                         }


    // 1. Acquisition

    if(graphic_mode==10)
    {
        for(j=0;j<5;j++)  for(i=0;i<600;i++) trace_analogique[j][i]=-1;
        for(j=0;j<10;j++) for(i=0;i<600;i++) trace_digital[j][i]   =-1;
        cpt_graphic=600;
    }

    if(graphic_mode>=1 && graphic_mode<=7) if(cpt_graphic==700)
    {
        for(j=0;j<5;j++)  for(i=0;i<600;i++) trace_analogique[j][i]=trace_analogique[j][i+100];
        for(j=0;j<10;j++) for(i=0;i<600;i++) trace_digital[j][i]   =trace_digital[j][i+100];
        cpt_graphic=600;
    }
    serial.init(szConfigPort,19200);

    if(capt_one)
    for(i=0;i<5;i++)
    {
        if(adr_ana[i]==-1) trace_analogique[i][cpt_graphic]=-1;
        else
        {
            adr=adr_ana[i];
            exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
            exchange(3,0,0,0,&dh,&dl,1,0); // disable sum
            trace_analogique[i][cpt_graphic]=dl;
        }
    }

    if(capt_one)
    for(i=0;i<10;i++)
    {
        if(adr_dig[i][0]==-1) trace_digital[i][cpt_graphic]=-1;
        else
        {
            capt=1;
            if(i>0) if(adr_dig[i][0]==adr_dig[i-1][0]) capt=0;
            if(capt)
            {
                adr=adr_dig[i][0];
                exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
                exchange(3,0,0,0,&dh,&dl,1,0); // disable sum
            }
            if(dl&(1<<adr_dig[i][1])) trace_digital[i][cpt_graphic]=1; else trace_digital[i][cpt_graphic]=0;
        }
    }

    if(capt_all_ana)
    for(cpt_graphic=0;cpt_graphic<700;cpt_graphic++)
    {
        for(i=0;i<10;i++) trace_digital[i][cpt_graphic]=-1;
        for(i=0;i<5 ;i++) trace_analogique[i][cpt_graphic]=-1;
        if(adr_ana[0]==-1) trace_analogique[0][cpt_graphic]=-1;
        else
        {
            if(cpt_graphic==0) { adr=adr_ana[0]; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); }

            exchange(3,0,0,0,&dh,&dl,1,0); // disable sum
            trace_analogique[0][cpt_graphic]=dl;
        }
        graphic_mode=0;
    }

    if(capt_all_dig)
    for(cpt_graphic=0;cpt_graphic<700;cpt_graphic++)
    {
        for(i=0;i<10;i++) trace_digital[i][cpt_graphic]=-1;
        for(i=0;i<5 ;i++) trace_analogique[i][cpt_graphic]=-1;
        if(adr_dig[0][0]==-1) trace_digital[i][cpt_graphic]=-1;
        else
        {
            if(cpt_graphic==0) { adr=adr_dig[0][0]; exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1); }

            exchange(3,0,0,0,&dh,&dl,1,0); // disable sum

            for(i=0;i<10;i++) if(adr_dig[i][0]==adr_dig[0][0])
            {
                if(dl&(1<<adr_dig[i][1])) trace_digital[i][cpt_graphic]=1; else trace_digital[i][cpt_graphic]=0;
            }
        }
        graphic_mode=0;
    }

    serial.close();


    // 2. Trace

    if(draw_all)
    {
        SelectObject(hdc,My_Font);
        SetBkMode(hdc,TRANSPARENT);
        //SetTextColor(hdc,RGB_PRESENTATION_TXT);
        SetTextColor(hdc,RGB(32,32,32));
        SelectObject(hdc,My_Brush_White);
        SelectObject(hdc,My_Pen_White);
        Rectangle(hdc,0,0,1600,1200);

        SelectObject(hdc,My_Brush_Black);
        SelectObject(hdc,My_Pen_Black);
        Rectangle(hdc,100,ya-255,800,ya);
        Rectangle(hdc,100,yd,800,yd+250);

        for(i=0;i<12;i++)
        {
            SelectObject(hdc,My_Brush_Grey);
            if(i<=9) if(graphic_mode==i) SelectObject(hdc,My_Pen_Green); else SelectObject(hdc,My_Pen_Red);
            Rectangle(hdc,100+60*i,10,100+50+60*i,30);
            if(i==0) _TextOut(102+60*i,12,"OFF");
            if(i==1) _TextOut(102+60*i,12,"100ms");
            if(i==2) _TextOut(102+60*i,12,"200ms");
            if(i==3) _TextOut(102+60*i,12,"500ms");
            if(i==4) _TextOut(102+60*i,12,"1s");
            if(i==5) _TextOut(102+60*i,12,"2s");
            if(i==6) _TextOut(102+60*i,12,"5s");
            if(i==7) _TextOut(102+60*i,12,"10s");
            if(i==8) _TextOut(102+60*i,12,"F ana");
            if(i==9) _TextOut(102+60*i,12,"F dig");
            if(i==10) _TextOut(102+60*i,12,"Load");
            if(i==11) _TextOut(102+60*i,12,"Save");
        }

        for(i=0;i<5;i++)
        {
            SelectObject(hdc,My_Brush_Grey);
            if(i==graphic_selected) SelectObject(hdc,My_Brush_Green);
            if(i==0) SelectObject(hdc,My_Pen_Yellow);
            if(i==1) SelectObject(hdc,My_Pen_Blue);
            if(i==2) SelectObject(hdc,My_Pen_Green);
            if(i==3) SelectObject(hdc,My_Pen_Red);
            if(i==4) SelectObject(hdc,My_Pen_Pink);
            Rectangle(hdc,10,ya-250+50*i,90,ya-250+50*i+20);
            _TextOut(12,ya-250+50*i+2,graphic_name[i]);
        }

        for(i=0;i<10;i++)
        {
            SelectObject(hdc,My_Brush_Grey);
            if(i==(graphic_selected-5)) SelectObject(hdc,My_Brush_Green);
            SelectObject(hdc,My_Pen_Green);
            Rectangle(hdc,10,yd+25*i,90,yd+25*i+20);
            _TextOut(12,yd+25*i+2,graphic_name[5+i]);
        }

        SelectObject(hdc,My_Pen_GreyD);
        for(j=0;j<10;j++)     { MoveToEx(hdc,100,yd+22+25*j,NULL); LineTo(hdc,800  ,yd+22+25*j); }
        for(i=0;i<=650;i+=50) { MoveToEx(hdc,100+i,yd      ,NULL); LineTo(hdc,100+i,yd+250    ); }

        SelectObject(hdc,My_Pen_GreyD);
        for(j=0;j<=250;j+=50) { MoveToEx(hdc,100,ya-j      ,NULL); LineTo(hdc,800  ,ya-j      );   sprintf(szTemp,"%d",j);  _TextOut(110,ya-5-j,szTemp); }
        for(i=0;i<=650;i+=50) { MoveToEx(hdc,100+i,ya      ,NULL); LineTo(hdc,100+i,ya-255    ); }

        for(j=0;j<5;j++)
        {
            j2=(j+cpt_graphic)%5;

            if(j2==0) SelectObject(hdc,My_Pen_Yellow);
            if(j2==1) SelectObject(hdc,My_Pen_Blue);
            if(j2==2) SelectObject(hdc,My_Pen_Green);
            if(j2==3) SelectObject(hdc,My_Pen_Red);
            if(j2==4) SelectObject(hdc,My_Pen_Pink);

            for(i=0;i<cpt_graphic;i++)
            if(trace_analogique[j2][i]!=-1 && trace_analogique[j2][i+1]!=-1)
            {
                MoveToEx(hdc,100+i,ya-trace_analogique[j2][i],NULL);
                LineTo(hdc,100+i+1,ya-trace_analogique[j2][i+1]);
            }
        }

        for(j=0;j<10;j++)
        {
            /*if(j==0)*/ SelectObject(hdc,My_Pen_Green);

            for(i=0;i<cpt_graphic;i++)
            if(trace_digital[j][i]!=-1)
            {
                MoveToEx(hdc,100+i,yd+22+25*j,NULL); LineTo(hdc,100+i,yd+22+25*j-20*trace_digital[j][i]+1);
            }
        }

    }

    if(draw_one)
    {
        for(j=0;j<5;j++)
        {
            if(j==0) SelectObject(hdc,My_Pen_Yellow);
            if(j==1) SelectObject(hdc,My_Pen_Blue);
            if(j==2) SelectObject(hdc,My_Pen_Green);
            if(j==3) SelectObject(hdc,My_Pen_Red);
            if(j==4) SelectObject(hdc,My_Pen_Pink);

            i=cpt_graphic-1;
            if(i>=0)
            if(trace_analogique[j][i]!=-1 && trace_analogique[j][i+1]!=-1)
            {
                MoveToEx(hdc,100+i,ya-trace_analogique[j][i],NULL);
                LineTo(hdc,100+i+1,ya-trace_analogique[j][i+1]);
            }
        }

        for(j=0;j<10;j++)
        {
            /*if(j==0)*/ SelectObject(hdc,My_Pen_Green);

            i=cpt_graphic;
            if(trace_digital[j][i]!=-1)
            {
                MoveToEx(hdc,100+i,yd+22+25*j,NULL); LineTo(hdc,100+i,yd+22+25*j-20*trace_digital[j][i]+1);
            }
        }

    }

    if(inc) cpt_graphic++;
    cpt_wait++;
    if(graphic_mode==8) graphic_mode=80;
    if(graphic_mode==9) graphic_mode=90;
    if(graphic_mode==10) graphic_mode=0;

}


void action_graphic(UINT action)
{
    int i;
    char szTemp[255];
    int ya=300;               // y bas du cadran analogique
    int yd=330;               // y haut du cadran numerique
    int len;
    int val,type;
    char* pt;

    if(action==WM_LBUTTONDOWN)
    {
        if(y_mouse>10 && y_mouse<90)
        {
            for(i=0;i<10;i++) if(x_mouse>(100+60*i) && x_mouse<(100+60*i+50)) { graphic_mode=i; cpt_wait=0; cpt_graphic=0; }
            i=10; if(x_mouse>(100+60*i) && x_mouse<(100+60*i+50)) { graphic_load(); graphic_mode=10; }
            i=11; if(x_mouse>(100+60*i) && x_mouse<(100+60*i+50)) { graphic_save(); graphic_mode=10; }
        }

        graphic_selected=-1;
        if(x_mouse>10 && x_mouse<90)
        {
            for(i=0;i<5 ;i++) if(y_mouse>=(ya-250+50*i) && y_mouse<=(ya-250+50*i+20)) { graphic_selected=i;   adr_ana[i]=-1; }
            for(i=0;i<10;i++) if(y_mouse>=(yd+25*i)     && y_mouse<=(yd+25*i+20)    ) { graphic_selected=i+5; adr_dig[i][0]=-1; }
            if(graphic_selected!=-1) { graphic_name[graphic_selected][0]='\0'; graphic_mode=10; }
        }
    }

    if(action==WM_CHAR) if(graphic_selected!=-1)
    {
        if(key_char==' ') { graphic_name[graphic_selected][0]='\0'; graphic_mode=10; }

        else if( (key_char>='a' && key_char<='z') || (key_char>='A' && key_char<='Z') || (key_char>='0' && key_char<='9') || key_char>='_' || key_char>='.')
        {
            len=strlen(graphic_name[graphic_selected]);
            if(len==9) { for(i=0;i<8;i++) graphic_name[graphic_selected][i]=graphic_name[graphic_selected][i+1]; len=8; }
            graphic_name[graphic_selected][len]=key_char;
            graphic_name[graphic_selected][len+1]='\0';
            graphic_mode=10;
        }

        else if( key_char==VK_RETURN )
        {
            int adr=-1,bit=-1;

            if(graphic_selected<5)
            {
                if(graphic_selected!=-1) if(graphic_name[graphic_selected][0]=='0' && (graphic_name[graphic_selected][1]=='x' || graphic_name[graphic_selected][1]=='X') ) { adr=adr_ana[graphic_selected]=atoh(&graphic_name[graphic_selected][2]); graphic_selected=-1; }
                if(graphic_selected!=-1) if(graphic_name[graphic_selected][0]>='0' && graphic_name[graphic_selected][0]<='9') { adr=adr_ana[graphic_selected]=atoi(graphic_name[graphic_selected]); graphic_selected=-1; }
                if(graphic_selected!=-1) if(var_adr_get(graphic_name[graphic_selected],&val,&type)) if(type==VARTYPE_ZV8)     { adr=adr_ana[graphic_selected]=0xc0+val; graphic_selected=-1;   }
            }

            if(graphic_selected>=5)
            {
                if(graphic_selected!=-1) if((pt=strstr(graphic_name[graphic_selected],"."))!=NULL) if(graphic_name[graphic_selected][0]=='0' && (graphic_name[graphic_selected][1]=='x' || graphic_name[graphic_selected][1]=='X') ) { adr=adr_dig[graphic_selected-5][0]=atoh(&graphic_name[graphic_selected][2]); bit=adr_dig[graphic_selected-5][1]=atoi(pt+1); graphic_selected=-1; }
                if(graphic_selected!=-1) if((pt=strstr(graphic_name[graphic_selected],"."))!=NULL) if(graphic_name[graphic_selected][0]>='0' &&  graphic_name[graphic_selected][0]<='9')  { adr=adr_dig[graphic_selected-5][0]=atoi(graphic_name[graphic_selected]); bit=adr_dig[graphic_selected-5][1]=atoi(pt+1); graphic_selected=-1; }
                if(graphic_selected!=-1)                                                           if(var_adr_get(graphic_name[graphic_selected],&val,&type)) if(type==VARTYPE_ZB)        { adr=adr_dig[graphic_selected-5][0]=0x20+val/8; bit=adr_dig[graphic_selected-5][1]=val%8; graphic_selected=-1;   }
            }

            graphic_mode=10;
            //sprintf(szTemp,"adr=%d bit=%d %d %d",adr,bit,adr_dig[0][0],adr_dig[0][1]); MessageBox(NULL,szTemp,"debug",MB_OK);
        }
    }


}



void draw_actgra(void)
{
    char szActiveStr_src[20001];
    char szActiveStr[20001];
    char* ptsrc;
    char* ptdst;
    char c;
    int zb_tab[32];
    int nb,repl,incro;
    int j;
    int adr,dh,dl;
    int line;
    char ch[4000],ch1[100];
    static char cpt=0;
    int i;


    cpt++;

    // 0. Save current line and update line box
    line=SendMessage( GetDlgItem(hwnd, ID_SEE_TEXT ), EM_GETFIRSTVISIBLELINE, 0, 0 );
    strcpy(ch,"");
    for(i=0;i<100;i++)
    {
        sprintf(ch1,"%04d\r\n",line+i+1);
        strcat(ch,ch1);
    }
    SendMessage(GetDlgItem(hwnd, ID_LINE_TEXT), WM_SETTEXT, 0, (LPARAM) ch);

    // 1. Get string from MAIN
    if(cpt&1) SendMessage( GetDlgItem(hwnd, ID_MAIN_TEXT), WM_GETTEXT, (WPARAM)20000, (LPARAM)szActiveStr_src);
    else SendMessage( GetDlgItem(hwnd, ID_MAIN_TEXT), WM_GETTEXT, (WPARAM)20000, (LPARAM)szActiveStr);

    // 2. change string once of two
    if(cpt&1)
    {
        // 2.1. get etape activity
        serial.init(szConfigPort,19200);
        for(j=0;j<8;j++)
        {
            adr=0x20+j;
            exchange(3,8,(adr>>8)&255,adr&255,NULL,NULL,1,1);
            exchange(3,0,0,0,&dh,&dl,1,1);
            zb_tab[j]=dl;
        }
        serial.close();

        // 2.2. replace szActiveStr_src --> szActiveStr
        ptsrc=szActiveStr_src; ptdst=szActiveStr;
        incro=0; repl=0;
        while(c=*ptsrc)
        {
            if(c=='[') incro=1;
            if(c==']') { incro=0; repl=0; }

            if(incro) if(c>='0' && c<='9')
            {
                incro=0;
                nb=atoi(ptsrc);
                if( (zb_tab[nb/8]) & (1<<(nb&7)) )  repl=1;
            }

            if(repl==1 && (c>='0' && c<='9')) *ptdst='*'; else *ptdst=c;

            ptsrc++; ptdst++;
        }
        *ptdst='\0';
    }

    // 3. Put string to SEE
    SendMessage( GetDlgItem(hwnd, ID_SEE_TEXT), WM_SETTEXT, 0, (LPARAM)szActiveStr);

    // 4. restore current line
    SendMessage( GetDlgItem(hwnd, ID_SEE_TEXT ), EM_LINESCROLL, (WPARAM) 0, (LPARAM) line);
}

void draw_pres(void)
{
    static int xy[10][2]={ {100,100},{200,10},{400,100},{10,50},{200,200},{400,300},{200,150},{10,100},{150,300},{400,10} };
    static int i=0;

    SelectObject(hdc,My_Brush_Green);
    SelectObject(hdc,My_Font);
    SetBkMode(hdc,TRANSPARENT);
    SetTextColor(hdc,RGB_PRESENTATION_TXT);
    Rectangle(hdc,0,0,1600,1200);
    _TextOut(xy[i/2][0],xy[i/2][1],PROGAPI_TITLE);
    i++; if(i==20) i=0;
}


#define LITTLE_HELP "" \
"\r\n=== PETITE AIDE ====" \
"\r\n" \
"\r\n- dans gra:" \
"\r\n  etape initiale: [[<numero>]] <eq de sortie>" \
"\r\n  etape         :  [<numero>]  <eq de sortie>" \
"\r\n  transition    : - <eq de transition>" \
"\r\n  liaisons      : | + -" \
"\r\n" \
"\r\n- dans pre,gra,post" \
"\r\n  equation complete" \
"\r\n" \
"\r\n- equation de sortie:" \
"\r\n  VB, clr VB, set VB" \
"\r\n  VAR=CST VAR+=CST VAR-=CST VAR++ VAR--" \
"\r\n" \
"\r\n- equation de transition" \
"\r\n  +-> VB/VAR --> op -+" \
"\r\n  +------------------+" \
"\r\n  VB (possible !=inv, �=ancienne VB, / =front_montant, \\=front_dezscendant [!]VB[�,/,\\]" \
"\r\n  ZAR test CST (avec test: ==,>=,<=,>,<,<>) " \
"\r\n " \
"\r\n- equation complete" \
"\r\n  equation de transition = eq de sortie VB =op eq de sortie VAR..." \
"\r\n  * x<numero> (etape initiale)" \
"\r\n  - x<numero> (etape)" \
"\r\n  > x<numero> (saut d'etape)" \
"\r\n " \
"\r\nVB=bit" \
"\r\nVAR=variable 8 ou 16 bits" \
"\r\n" \
"\r\nNotes:" \
"\r\n- Ne pas utiliser les tabulations (utiliser des espaces)" \
"\r\n- sous une etape, placer la transition - ou une liaison juste apres le dernier [" \
"\r\n  [0] OUI    [0] NON    [0] NON    [0] OUI    [0] NON" \
"\r\n   -         -            -         |         |      "\
"\r\n" \
"\r\nex: (lorsque ic0 et ic2 active, la sortie ob0 s'active durant 10 secondes)" \
"\r\n" \
"\r\n  +-----+            " \
"\r\n  |     |            " \
"\r\n  |    [0]           " \
"\r\n  |     |            " \
"\r\n  |     - ic0.ic2    " \
"\r\n  |     |            " \
"\r\n  |    [1] t0=100,ob0" \
"\r\n  |     |            " \
"\r\n  |     - t0==0      " \
"\r\n  |     |            " \
"\r\n  +-----+            " \
"\r\n" \
"\r\nou" \
"\r\n" \
"\r\n     Y 0           " \
"\r\n     |             " \
"\r\n    [0]            " \
"\r\n     |             " \
"\r\n     - ic0.ic2     " \
"\r\n     |             " \
"\r\n    [1] t0=1000,ob0" \
"\r\n     |             " \
"\r\n     - t0==0       " \
"\r\n     |             " \
"\r\n     V 0           " \
"\r\n" \
"\r\nou" \
"\r\n" \
"\r\n* x0             " \
"\r\nic0 . ic2 > x1   " \
"\r\n- x1             " \
"\r\nt0==0 . !ico > x0" \
"\r\nx1/ =op to=100   " \
"\r\nx1  = ob0        " \
"\r\n" \
"\r\n" \
"\r\n" \
"\r\nBrochage des UC" \
"\r\n" \
"\r\n          RT                          " \
"\r\n          XX                          " \
"\r\n         G||               G          " \
"\r\nBBBBBBBB+NCCCC    BBBBBBBB+NDDDDCCCCDD" \
"\r\n765432105D7564    765432105D7654765432" \
"\r\n##############    ####################" \
"\r\n# 16f873/876#     #    16f874/877   #" \
"\r\n##############    ####################" \
"\r\nRAAAAAAGXXCCCC    RAAAAAAEEE+GXXCCCCDD" \
"\r\nA012345NIO0123    A0123450125NIO012301" \
"\r\nZ      D          Z          D        " \
"\r\n" \
"\r\n" \
"\r\nPour plus d'information, lire le manuel utilisateur et le site web http:/ /www.chez.com/udelmas"
/*
"\r\n  XX                   RT                          " \
"\r\n  IO                   XX                          " \
"\r\n  ||                  G||               G          " \
"\r\nAAAA+BBBB    BBBBBBBB+NCCCC    BBBBBBBB+NDDDDCCCCDD" \
"\r\n107657654    765432105D7564    765432105D7654765432" \
"\r\n#########    ##############    ####################" \
"\r\n #16f628#     # 16f873/876#     #    16f874/877   #" \
"\r\n#########    ##############    ####################" \
"\r\nAAAAGBBBB    RAAAAAAGXXRRRR    RAAAAAAEEE+GXXCCCCDD" \
"\r\n2345N0123     012345NIO0123     0123450125NIO012301" \
"\r\n   |D ||            D                     D        " \
"\r\n   R  RT                                           " \
"\r\n      XX                                           " \
*/




/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

        W I N D O W S    F U N C T I O N S   ( M A I N   &   M E S S A G E   L O O P )

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/






/*****************************************************************************/
/* MAIN AND CALLBACK FUNCTIONS FOR GENERAL SEQUENCING                        */
/*****************************************************************************/


/* Make the class name into a global variable */
char szClassName[ ] = "WindowsApp";
int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nFunsterStil)
{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */

    /* Save the program instance */
    hInst=hThisInstance;

    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof(WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wincl.lpszMenuName = "MAINMENU";
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use light-gray as the background of the window */
    wincl.hbrBackground = (HBRUSH) My_Brush_White; //GetStockObject(WHITE_BRUSH);

    /* Register the window class, if fail quit the program */
    if(!RegisterClassEx(&wincl)) return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx(
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           PROGAPI_TITLE,       /* Title Text */
           WS_OVERLAPPEDWINDOW, /* default window */
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           850,/*600*/          /* The programs width */
           650,/*425*/          /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

    /* Make the window visible on the screen */
    ShowWindow(hwnd, nFunsterStil);
    /* Run the message loop. It will run until GetMessage( ) returns 0 */
    while(GetMessage(&messages, NULL, 0, 0))
    {
           /* Translate virtual-key messages into character messages */
           TranslateMessage(&messages);
           /* Send message to WindowProcedure */
           DispatchMessage(&messages);
    }

    /* The program return-value is 0 - The value that PostQuitMessage( ) gave */
    return messages.wParam;
}


/* This function is called by the Windows function DispatchMessage( ) */
LRESULT CALLBACK WindowProcedure(HWND _hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    char szTemp[1024];
    static int  en_cours=0;
    static int x,y,ysep;
    int line,i;
    char ch[4000],ch1[100];
    int ret;
    static int cpt=0;
    static int load_conf_order=0;


    hwnd=_hwnd;
    hdc=GetDC(hwnd);

    switch (message)                   /* handle the messages */
    {
        case WM_CREATE :

            SetTimer(hwnd,1,100,NULL);
            //SetTimer(hwnd,1,250,NULL);
            //creata
            CreateWindow("EDIT", "",/*WS_BORDER |*/ WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE | ES_WANTRETURN, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hwnd, (HMENU)ID_MAIN_TEXT , hInst, NULL);
            CreateWindow("EDIT", "",/*WS_BORDER |*/ WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE | ES_WANTRETURN, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hwnd, (HMENU)ID_ERROR_TEXT, hInst, NULL);
            CreateWindow("EDIT", "",/*WS_BORDER |*/ WS_CHILD | WS_VISIBLE |                           ES_MULTILINE | ES_WANTRETURN, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hwnd, (HMENU)ID_LINE_TEXT , hInst, NULL);
            CreateWindow("EDIT", "",/*WS_BORDER |*/ WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE | ES_WANTRETURN, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hwnd, (HMENU)ID_SEE_TEXT  , hInst, NULL);
            CreateWindow("EDIT", "",/*WS_BORDER |*/ WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE | ES_WANTRETURN, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hwnd, (HMENU)ID_CONF_TEXT , hInst, NULL);
            //font
            SendDlgItemMessage(hwnd, ID_MAIN_TEXT , WM_SETFONT, (WPARAM)My_Font, MAKELPARAM(TRUE, 0));
            SendDlgItemMessage(hwnd, ID_ERROR_TEXT, WM_SETFONT, (WPARAM)My_Font, MAKELPARAM(TRUE, 0));
            SendDlgItemMessage(hwnd, ID_LINE_TEXT , WM_SETFONT, (WPARAM)My_Font, MAKELPARAM(TRUE, 0)); // (WPARAM)GetStockObject(SYSTEM_FIXED_FONT)
            SendDlgItemMessage(hwnd, ID_SEE_TEXT  , WM_SETFONT, (WPARAM)My_Font, MAKELPARAM(TRUE, 0));
            SendDlgItemMessage(hwnd, ID_CONF_TEXT , WM_SETFONT, (WPARAM)My_Font, MAKELPARAM(TRUE, 0));
            //disable,hide,read only
            EnableWindow(GetDlgItem(hwnd, ID_LINE_TEXT), 0 );
            SendDlgItemMessage(     hwnd, ID_ERROR_TEXT, EM_SETREADONLY, 1, 0);
            //EnableWindow(GetDlgItem(hwnd, ID_SEE_TEXT), 0 );
            SendDlgItemMessage(     hwnd, ID_SEE_TEXT, EM_SETREADONLY, 1, 0);
            ShowWindow(  GetDlgItem(hwnd, ID_SEE_TEXT ), SW_HIDE );
            ShowWindow(  GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE );

            //mode=MODE_EDIT;
            mode=MODE_PRES;

            sprintf(ch,"Welcome to %s \r\n- Select the definition file for your automate\r\n- Create or Edit a grapcet file and compile it\r\n- Load and Test it with RS232 bootloader/monitor ",PROGAPI_TITLE);
            //SendMessage(GetDlgItem(hwnd, ID_ERROR_TEXT), WM_SETTEXT, 0, (LPARAM) ch);
            ErrorScreen.add(ch);

            init_load_conf();
            load_conf_order=1;

            break;

        case WM_TIMER:
            if(load_conf_order) { load_conf_order=0; load_conf(); }

            if(wParam!=1) break;
            if(en_cours==1) break;
            en_cours=1;
            cpt++;
            //if(mode==MODE_RS232 ) draw_rs232();

            if(mode==MODE_EDIT || mode==MODE_SEE || mode==MODE_CONF) if((cpt%2)==0)
            {
                if(mode==MODE_EDIT) line=SendMessage( GetDlgItem(hwnd, ID_MAIN_TEXT), EM_GETFIRSTVISIBLELINE, 0, 0 );
                if(mode==MODE_SEE ) line=SendMessage( GetDlgItem(hwnd, ID_SEE_TEXT ), EM_GETFIRSTVISIBLELINE, 0, 0 );
                if(mode==MODE_CONF) line=SendMessage( GetDlgItem(hwnd, ID_CONF_TEXT), EM_GETFIRSTVISIBLELINE, 0, 0 );
                strcpy(ch,"");
                for(i=0;i<100;i++)
                {
                    sprintf(ch1,"%04d\r\n",line+i+1);
                    strcat(ch,ch1);
                }
                SendMessage(GetDlgItem(hwnd, ID_LINE_TEXT), WM_SETTEXT, 0, (LPARAM) ch);
            }

            if(mode==MODE_ACTGRA)    if((cpt%5)==0) draw_actgra();

            if(mode==MODE_RS232ZBZV) if((cpt%2)==0) draw_rs232zbzv();

            if(mode==MODE_RS232IO)   draw_rs232io();

            if(mode==MODE_RS232)     if((cpt%2)==0) draw_rs232();

            if(mode==MODE_GRAPHIC)   draw_graphic();

            if(mode==MODE_PRES)      if((cpt%3)==0)
            {
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE );
                    draw_pres();
            }


            en_cours=0;
            break;

        case WM_SETFOCUS:
             //SetFocus(GetDlgItem(hwnd, IDC_MAIN_TEXT));
             break;

        case WM_MOVE:
            break;

        case WM_SIZE:
            if(wParam != SIZE_MINIMIZED)
            {
                x=LOWORD(lParam);
                y=HIWORD(lParam);

                ysep=(3*y)/4-1;
                //if (y-ysep>100) ysep=y-100;

                MoveWindow(GetDlgItem(hwnd, ID_LINE_TEXT ) , 0,      1,   50, ysep  , TRUE);
                MoveWindow(GetDlgItem(hwnd, ID_MAIN_TEXT ) ,51,      1, x-51, ysep  , TRUE);
                MoveWindow(GetDlgItem(hwnd, ID_CONF_TEXT ) ,51,      1, x-51, ysep  , TRUE);
                MoveWindow(GetDlgItem(hwnd, ID_SEE_TEXT  ) ,51,      1, x-51, ysep  , TRUE);
                MoveWindow(GetDlgItem(hwnd, ID_ERROR_TEXT) , 0, ysep+2, x   , y-ysep, TRUE);

                UpdateWindow(hwnd);
            }
            break;

        case WM_PAINT:
            break;

        case WM_LBUTTONUP:
            x_mouse=LOWORD(lParam);
            y_mouse=HIWORD(lParam);
            break;

        case WM_LBUTTONDOWN:
            x_mouse=LOWORD(lParam);
            y_mouse=HIWORD(lParam);
            if(mode==MODE_RS232)   action_rs232(  WM_LBUTTONDOWN);
            if(mode==MODE_RS232IO) action_rs232io(WM_LBUTTONDOWN);
            if(mode==MODE_GRAPHIC) action_graphic(WM_LBUTTONDOWN);
            break;

        case WM_RBUTTONUP:
            x_mouse=LOWORD(lParam);
            y_mouse=HIWORD(lParam);
            break;

        case WM_RBUTTONDOWN:
            x_mouse=LOWORD(lParam);
            y_mouse=HIWORD(lParam);
            break;

        case WM_CHAR:
            key_char=LOWORD(wParam);
            if(mode==MODE_RS232)   action_rs232(WM_CHAR);
            if(mode==MODE_GRAPHIC) action_graphic(WM_CHAR);
            break;

        case WM_COMMAND:
            if(mode==MODE_CONF && (LOWORD(wParam)>=800) && (LOWORD(wParam)<=900) && (LOWORD(wParam)!=CM_SELECTDEF) )  { ErrorScreen.add("update config file"); SaveFile(GetDlgItem(hwnd, ID_CONF_TEXT), szConfFileName); load_conf();  }
            switch(LOWORD(wParam))
            {
                case CM_NEWGRA:
                    if(szGraFileName[0]!='\0')
                    {
                        if( MessageBox(hwnd,"\nYou will loose current unsaved work\nDo you want to continue","progapi",MB_OK | MB_YESNO | MB_ICONWARNING) == IDNO ) break;
                    }
                    szGraFileName[0]=szLitFileName[0]=szHexFileName[0]='\0';
                    draw_clear();
                    SendMessage(GetDlgItem(hwnd, ID_MAIN_TEXT), WM_SETTEXT, 0, (LPARAM) "");
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    strcpy(szTemp,"Fichier graphcet progapi 2004 \r\n\r\n-projet      : \r\n-description : \r\n-version     : \r\n-revision    : \r\n-historique  : \r\n-notes       :\r\n \r\n@PRE \r\n \r\n@GRA \r\n \r\n@POST \r\n \r\n");
                    SendMessage (GetDlgItem(hwnd, ID_MAIN_TEXT ), WM_SETTEXT, 0, (LPARAM)szTemp);
                    mode=MODE_EDIT;
                    UpdateWindow(hwnd);
                    break;

                case CM_OPENGRA:
                    SelectGraFileOpen();
                    LoadGraFile();
                    UpdateLitHexFiles();
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    mode=MODE_EDIT;
                    UpdateWindow(hwnd);
                    break;

                case CM_SAVEGRA:
                    if(szGraFileName[0]=='\0') { MessageBox(hwnd,"No File Selected, Use Save As","progapi",MB_OK | MB_ICONERROR); break; }
                    SaveGraFile();
                    break;

                case CM_SAVEASGRA:
                    SelectGraFileSaveAs();
                    SaveGraFile();
                    UpdateLitHexFiles();
                    break;

                case CM_SELECTDEF:
                    SelectDefFile();
                    ret=load_def_file();
                    if(ret==0) MessageBox(hwnd,"Cannot open the definition file","progapi",MB_OK | MB_ICONERROR);
                    else if(ret==2) MessageBox(hwnd,"Missing config variable in definition file","progapi",MB_OK | MB_ICONERROR);
                    else { save_conf(); ErrorScreen.add("update config file"); }
                    if(mode==MODE_CONF) LoadFile(GetDlgItem(hwnd, ID_CONF_TEXT), szConfFileName);
                    break;

                case CM_EXIT:
                    draw_clear();
                    PostQuitMessage(0);
                    break;

                case CM_COMPILE:
                    if(szGraFileName[0]=='\0') { MessageBox(hwnd,"Please, choose first the filename for your .gra file\n\n(with save as menu)","progapi",MB_OK | MB_ICONERROR); break; }
                    if(szDefFileName[0]=='\0') { MessageBox(hwnd,"Please, select first the definition filename\n\n(with select definition file menu)","progapi",MB_OK | MB_ICONERROR); break; }
                    SaveGraFile();
                    sprintf(szTemp,"Compile:\n\nGra: %s\nDef: %s\n\n-->\n\nLit: %s\nHex: %s", szGraFileName, szDefFileName, szLitFileName, szHexFileName);
                    MessageBox(hwnd,szTemp,"progapi",MB_OK|MB_ICONINFORMATION);
                    ErrorScreen.clr();
                    sprintf(szTemp,"Compile:\r\nGra: %s\r\nDef: %s\r\n-->\r\nLit: %s\r\nHex: %s\r\n", szGraFileName, szDefFileName, szLitFileName, szHexFileName);
                    ErrorScreen.add(szTemp);
                    ret=compile();
                    if(ret==0) MessageBox(hwnd,"Compilation ERROR","progapi",MB_OK | MB_ICONERROR);
                    break;

                case CM_DOWNLOADINT:
                    break;

                case CM_DOWNLOADGRA:
                    download_gra();
                    break;

                case CM_MONITOR:
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE );
                    mode=MODE_RS232;
                    UpdateWindow(hwnd);
                    break;

                case CM_INOUT:
                    cpt_rs232io=0;
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE );
                    mode=MODE_RS232IO;
                    UpdateWindow(hwnd);
                    break;

                case CM_GRAPHIC:
                    cpt_graphic=0;
                    cpt_wait=0;
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE );
                    mode=MODE_GRAPHIC;
                    UpdateWindow(hwnd);
                    break;

                case CM_ZBZV:
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE );
                    mode=MODE_RS232ZBZV;
                    UpdateWindow(hwnd);
                    break;

                case CM_ACTIVEGRA:
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_SHOWNORMAL );
                    mode=MODE_ACTGRA;
                    UpdateWindow(hwnd);
                    break;

                case CM_GRAPHCET:
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    //EnableWindow(GetDlgItem(hwnd, ID_MAIN_TEXT), 1 );
                    mode=MODE_EDIT;
                    UpdateWindow(hwnd);
                    break;

                case CM_CONFIG:
                    draw_clear();
                    LoadFile(GetDlgItem(hwnd, ID_CONF_TEXT), szConfFileName);
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    mode=MODE_CONF;
                    UpdateWindow(hwnd);
                    break;

               case CM_DEF:
                    draw_clear();
                    LoadFile(GetDlgItem(hwnd, ID_SEE_TEXT), szDefFileName);
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_SHOWNORMAL );
                    mode=MODE_SEE;
                    UpdateWindow(hwnd);
                    break;

               case CM_LIT:
                    draw_clear();
                    LoadFile(GetDlgItem(hwnd, ID_SEE_TEXT), szLitFileName);
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_SHOWNORMAL );
                    mode=MODE_SEE;
                    UpdateWindow(hwnd);
                    break;

               case CM_HEX:
                    draw_clear();
                    LoadFile(GetDlgItem(hwnd, ID_SEE_TEXT), szHexFileName);
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_SHOWNORMAL );
                    mode=MODE_SEE;
                    UpdateWindow(hwnd);
                    break;

                case CM_ABOUT:
                    sprintf(szTemp,"%s\n\nUlysse Delmas-Begue\nudelmas@chez.com\n\nhttp://www.chez.com/udelmas",PROGAPI_TITLE);
                    MessageBox(hwnd,szTemp,"About",MB_OK|MB_ICONINFORMATION);
                    break;

                case CM_HELP:
                    draw_clear();
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_SHOWNORMAL );
                    SendMessage(GetDlgItem(hwnd, ID_SEE_TEXT), WM_SETTEXT, 0, (LPARAM) LITTLE_HELP);
                    mode=MODE_SEE;
                    UpdateWindow(hwnd);
                    break;

                case CM_PERSHELP:
                    draw_clear();
                    LoadFile(GetDlgItem(hwnd, ID_SEE_TEXT), szPersonalHelpFileName);
                    ShowWindow  (GetDlgItem(hwnd, ID_MAIN_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_CONF_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_LINE_TEXT ), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_ERROR_TEXT), SW_SHOWNORMAL );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_HIDE       );
                    ShowWindow  (GetDlgItem(hwnd, ID_SEE_TEXT  ), SW_SHOWNORMAL );
                    mode=MODE_SEE;
                    UpdateWindow(hwnd);
                    break;

                case CM_USERMANUAL:
                    ShellExecute(NULL,"open",szUserManualFileName, NULL, NULL, SW_SHOWNORMAL);
                    break;

                default:
                    break;
            }
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            break;

    }

    ReleaseDC(hwnd,hdc);

    return DefWindowProc(hwnd, message, wParam, lParam);
}






/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

        C O M P I L A T I O N   F U N C T I O N S

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/






/******* FCT de compilation ********/
int CompileError;   // Error number
char szError[1024]; // Used to build messages to display (error, information ...)
int hex_gra[2048];  // hex graphcet to put in PIC memory
int hex_gra_ind=0;  // index of hex_gra (next free place)
FILE* pf_lit;       // pointer on lit file (szLitFileName)
FILE* pf_hex;       // pointer on hex file (szHexFileName)
int CurrLine;       // Current analyzed line


/*==============================================================================

  fonctions de chargement et extraction du fichier de definition

==============================================================================*/


char hex_line[500][100];
int  hex_ind=0;
char szdef_NAME[100]="";
int def_ZG_START=-1;
int def_ZG_STOP=-1;
int def_ZB_NEW=-1;
int def_ZB_OLD=-1;
int def_ZV_START=-1;
int def_BMON_START=-1;
int def_BMON_STOP=-1;

#define STR_STR_NB 500
#define STR_CHAR_NB 10000
char str_char[STR_CHAR_NB];
int  str_val[STR_STR_NB];
int  str_ind[STR_STR_NB];
int  str_type[STR_STR_NB];
int  str_next;
int  str_no;


/*------------------------------------------------------------------------------
NAME  : var_adr_init
DESCR : initialise les associations
ARG   : void
RETURN: void
------------------------------------------------------------------------------*/
void var_adr_init(void)
{
	int i;
	for(i=0;i<STR_STR_NB;i++) str_ind[i]=-1;
	str_next=0;
	str_no=0;
}


/*------------------------------------------------------------------------------
NAME  : var_adr_add
DESCR : ajoute un nom avec sa valeur et son type associe
ARG   : s: nom
        val: valeur associee au nom
        type: type associe au nom
RETURN: 0: erreur, plus de place
        1: ok
------------------------------------------------------------------------------*/
#define VARTYPE_ZB 0
#define VARTYPE_ZV8 1
#define VARTYPE_ZV16 2
int var_adr_add(char s[],int dat,int type)
{
    char cur_char[100];

	strcpy(cur_char,s);
	/**/strlwr(cur_char);

    if(str_no>=STR_STR_NB) return 0;
    if((str_next+strlen(cur_char)+10)>=STR_CHAR_NB) return 0;

	strcpy(&str_char[str_next],cur_char);
	str_ind[str_no]=str_next;
	str_val[str_no]=dat;
	str_type[str_no]=type;
	str_next+=strlen(cur_char)+1;
	str_no++;

	return 1;
}


/*------------------------------------------------------------------------------
NAME  : var_adr_get
DESCR : indique la valeur et le type associes a un nom si il a ete definit
ARG   : s: nom
        val: valeur associee au nom
        type: type associe au nom
RETURN: 0: le nom n'a pas ete definit
        1: ok
------------------------------------------------------------------------------*/
int var_adr_get(char s[],int* val,int* type)
{
	int i;
	char sz[100];

	strcpy(sz,s);
	/**/strlwr(sz);
	for(i=0;i<str_no;i++) if(!strcmp(sz,&str_char[str_ind[i]]))
	{
		*val=str_val[i];
		*type=str_type[i];
		return 1;
	}
	return 0;
}


/*------------------------------------------------------------------------------
NAME  : var_name_get
DESCR : indique le 1er nom rencontre pour la variable de type et adresse specifies
ARG   : adr: variable adresse
        type: variable type
        szName: variable name
RETURN: 0: le nom n'a pas ete definit
        1: ok
------------------------------------------------------------------------------*/
int var_name_get(int adr, int type, char szName[])
{
	int i;

	for(i=0;i<str_no;i++)
    {
        if(adr==str_val[i] && type==str_type[i])
        {
	        strcpy(szName,&str_char[str_ind[i]]);
    		return 1;
        }
	}
    strcpy(szName,"");
	return 0;
}


/*------------------------------------------------------------------------------
NAME  : var_verif
DESCR : donne l'enregistrement dont l'indes est specifie
ARG   : ind: index
        s: nom
        val: valeur associee au nom
        type: type associe au nom
RETURN: 0: le nom n'a pas ete definit
        1: ok
------------------------------------------------------------------------------*/
int var_verif(int ind,char s[],int* val,int* type)
{
    if(ind>=str_no) return 0;

    strcpy(s,&str_char[str_ind[ind]]);
    *val=str_val[ind];
    *type=str_type[ind];

    return 1;
}


#define STEP_WAITTYPE 0
#define STEP_WAITADR  1
#define STEP_WAITVAR  2
/*------------------------------------------------------------------------------
NAME  : str2int
DESCR : extract int from a decimal or hexadecimalo string
ARG   : void
RETURN: void
NOTE  : type is detected by x letter (ie 0x31 return 49 decimal)
------------------------------------------------------------------------------*/
int str2int(char sz[])
{
    char c;
    char* pt;
    int val=0;
    int type=0; //0:dec 1:hex

    pt=sz;

    while(c=*pt++)
    {
        if(c=='x' || c=='X') type=1; // hex

        if(type==0) if(c>='0' && c<='9') val=10*val+c-'0';

        if(type==1) { if(c>='0' && c<='9') val=16*val+c-'0';
                      if(c>='a' && c<='f') val=16*val+c-'a'+10;
                      if(c>='A' && c<='F') val=16*val+c-'A'+10; }
    }

    return val;
}


/*------------------------------------------------------------------------------
NAME  : load_def_file
DESCR : charge un fichier de definition
ARG   : void
RETURN: 0: cannot open definition file
        1: ok
        2: variable non initialisee
------------------------------------------------------------------------------*/
int load_def_file(void)
{
    FILE* pf;
    char szCurr[99];
    int adr,type,get,step,i;

	var_adr_init();
    hex_ind=0;
    strcpy(szdef_NAME,"");
    def_ZG_START=-1;
    def_ZG_STOP=-1;
    def_ZB_NEW=-1;
    def_ZB_OLD=-1;
    def_ZV_START=-1;
    def_BMON_START=-1;
    def_BMON_STOP=-1;

    pf=fopen(szDefFileName,"rt");
    if(pf==NULL) return 0;

    get=1;
    while(1)
    {
        if(get) if(fscanf(pf," %s",szCurr)==EOF) break;
        get=1;
        strlwr(szCurr);

        if(STR_SAME stricmp(szCurr,"@CONFIG"))
        {
            step==0;
            while(1)
            {
                if(fscanf(pf," %s",szCurr)==EOF) break;
                strlwr(szCurr);
                if(szCurr[0]=='@') break;

                switch(step)
                {
                    case 1: strcpy(szdef_NAME,szCurr);      step=0; break;
                    case 2: def_ZG_START  =str2int(szCurr); step=0; break;
                    case 3: def_ZG_STOP   =str2int(szCurr); step=0; break;
                    case 4: def_ZB_NEW    =str2int(szCurr); step=0; break;
                    case 5: def_ZB_OLD    =str2int(szCurr); step=0; break;
                    case 6: def_ZV_START  =str2int(szCurr); step=0; break;
                    case 7: def_BMON_START=str2int(szCurr); step=0; break;
                    case 8: def_BMON_STOP =str2int(szCurr); step=0; break;

                    default:
                        if(STR_SAME strcmp(szCurr,"name"      )) step=1;
                        if(STR_SAME strcmp(szCurr,"zg_start"  )) step=2;
                        if(STR_SAME strcmp(szCurr,"zg_stop"   )) step=3;
                        if(STR_SAME strcmp(szCurr,"zb_new"    )) step=4;
                        if(STR_SAME strcmp(szCurr,"zb_old"    )) step=5;
                        if(STR_SAME strcmp(szCurr,"zv_start"  )) step=6;
                        if(STR_SAME strcmp(szCurr,"bmon_start")) step=7;
                        if(STR_SAME strcmp(szCurr,"bmon_stop" )) step=8;
                        break;
                }
            }
            get=0; // yet @... in szCurr
        }

        if(STR_SAME stricmp(szCurr,"@NAMES"))
        {
            step==STEP_WAITTYPE;
            while(1)
            {
                if(fscanf(pf," %s",szCurr)==EOF) break;
                strlwr(szCurr);
                if(szCurr[0]=='@') break;

                if(step==STEP_WAITADR)                 { adr=str2int(szCurr); step=STEP_WAITVAR; }
                else
                {
                    if(STR_SAME strcmp(szCurr,"zb"))   { type=VARTYPE_ZB;     step=STEP_WAITADR; }
                    if(STR_SAME strcmp(szCurr,"zv8"))  { type=VARTYPE_ZV8;    step=STEP_WAITADR; }
                    if(STR_SAME strcmp(szCurr,"zv16")) { type=VARTYPE_ZV16;   step=STEP_WAITADR; }
                    if(step==STEP_WAITVAR)             { var_adr_add(szCurr,adr,type); }
                }
            }
            get=0; // yet @... in szCurr
        }

        if(STR_SAME stricmp(szCurr,"@HEX"))
        {
            while(1)
            {
                if(fscanf(pf," %s",szCurr)==EOF) break;
                strlwr(szCurr);
                if(szCurr[0]=='@') break;

                /*if(strstr(szCurr,"...")==NULL) supprime line !*/ strcpy(hex_line[hex_ind++],szCurr);
            }
            get=0; // yet @... in szCurr
        }

    }

    fclose(pf);


    pf=fopen("verif_def.txt","wt");
    if(pf)
    {
        fprintf(pf,"\nVerification du chargement du fichier de definition");

        fprintf(pf,"\n\n\n@CONFIG\n");
        fprintf(pf,"\nNAME        %s",szdef_NAME);
        fprintf(pf,"\nZG_START    0x%x",def_ZG_START);
        fprintf(pf,"\nZG_STOP     0x%x",def_ZG_STOP);
        fprintf(pf,"\nZB_NEW      0x%x",def_ZB_NEW);
        fprintf(pf,"\nZB_OLD      0x%x",def_ZB_OLD);
        fprintf(pf,"\nZV_START    0x%x",def_ZV_START);
        fprintf(pf,"\nBMON_START  0x%x",def_BMON_START);
        fprintf(pf,"\nBMON_STOP   0x%x",def_BMON_STOP);

        fprintf(pf,"\n\n\n@NAMES\n");
        i=0;
        while(var_verif(i, szCurr, &adr, &type))
        {
            if(type==VARTYPE_ZB)        fprintf(pf,"\nzb      ");
            else if(type==VARTYPE_ZV8)  fprintf(pf,"\nzv8     ");
            else if(type==VARTYPE_ZV16) fprintf(pf,"\nzv16    ");
            else                        fprintf(pf,"\ntype=%d  ",type);

            fprintf(pf," %3d",adr); fprintf(pf," %s",szCurr);

            i++;
        }

        fprintf(pf,"\n\n\n@HEX\n");
        for(i=0;i<hex_ind;i++) fprintf(pf,"\n%s",hex_line[i]);

        fclose(pf);
    }


    if( szdef_NAME[0]=='\0' || def_ZG_START==-1 || def_ZG_STOP==-1 || def_ZB_NEW==-1 || def_ZB_OLD==-1 || def_ZV_START==-1 || def_BMON_START==-1 || def_BMON_STOP==-1) return 2;
    return 1;
}


/*==============================================================================

  fonctions de chargement du fichier gra en memoire

==============================================================================*/
#define GRA_MEM_ROW 500
#define GRA_MEM_COL 100
char gra_mem[GRA_MEM_ROW][GRA_MEM_COL];
int SpaceByTab=4;

#define SIZE_DECOMPOSE 50
int  decomposed_string_nb;
char decomposed_string[SIZE_DECOMPOSE][100]; // decomposed current line
int  decomposed_string_type[SIZE_DECOMPOSE];
int  decomposed_string_adrval[SIZE_DECOMPOSE];
#define TYPE_NOTHING 0
#define TYPE_UNKNOWN 1
#define TYPE_LIT     2
#define TYPE_ZB      3
#define TYPE_ZV8     4
#define TYPE_ZV16    5
#define TYPE_OP      6
int decomposed_string_inv[SIZE_DECOMPOSE];
#define TYPE_NOTINV  0
#define TYPE_INV     1
int decomposed_string_oldedge[SIZE_DECOMPOSE];
#define TYPE_ZBNEW   0
#define TYPE_ZBOLD   1
#define TYPE_ZBUP    2
#define TYPE_ZBDOWN  3


/*------------------------------------------------------------------------------
NAME  : decompose
DESCR : decompose the specified string
ARG   : szStr: string to decomose
RETURN: substring decomposition number
------------------------------------------------------------------------------*/
int decompose(char* szStr)
{
    int i;
	int no_char;
	int no_str;
    int in_str;
	char c;
    char* pt;

    pt=szStr;

    for(i=0;i<SIZE_DECOMPOSE;i++) decomposed_string[i][0]=decomposed_string[i][1]='\0';
    no_str=-1;
	no_char=0;
    in_str=0;

	while(c=*pt++)
	{
		switch(c)
		{
			case ' ' :
			case '\t': no_char=0; in_str=0;
                       break;
			case '=' : case '*' : case '+' : case '-' :
			case '&' : case '|' : case '^' : case '$' : case '�' :
			case '[' : case ']' : case '(' : case ')' : case '{' : case '}' :
            case '/' : case '\\':
			case '\'': case '\"':
			case '!' : case '?' :
            case '~' :
			case '>' : case '<' :
            case '#' :
            case '\n': case '\r':
			case '.' : /*case ':' :*/case ',' : case ';' :
			case '%' : no_str++;
                       decomposed_string[no_str][0]=c;
                       decomposed_string[no_str][1]='\0';
                       no_char=0; in_str=0;
                       break;
			default  : if(in_str==0) {in_str=1; no_str++; }
                       decomposed_string[no_str][no_char++]=c;
                       decomposed_string[no_str][no_char]='\0';
					   break;
		}

		if(no_char>=99 || no_str>=SIZE_DECOMPOSE) break;
	}

    decomposed_string_nb=no_str+1;

	return decomposed_string_nb;
}


/*------------------------------------------------------------------------------
NAME  : is_lit
DESCR : indicate if passed string is a decimal litteral
ARG   : szStr: string to analyze
RETURN: 1: yes
        0: no
------------------------------------------------------------------------------*/
int is_lit(char* szStr)
{
    int ok=2;
    char* pt;
    char c;

    pt=szStr;

    while(c=*pt++)
    {
        if(c>='0' && c<='9')
        {
            if(ok==2) ok=1;
        }
        else
        {
            ok=0;
        }
    }

    if(ok==2) ok=0;

    return ok;
}


/*------------------------------------------------------------------------------
NAME  : is_date
DESCR : indicate if passed string is a date and compute its 16bits value
ARG   : szStr: string to analyze
        val  : returned value
RETURN: 1: yes
        0: no
------------------------------------------------------------------------------*/
int is_date(char* szStr, int* val)
{
    char ch[512];
    int len;
    int day=0,hour=0,min=0,ok=0;

    strcpy(ch,szStr); strlwr(ch);
    len=strlen(ch);
    ok=0;

    // x:xx
    if(len==4) if(ch[0]>='0' && ch[0]<='9') if(ch[1]==':') if(ch[2]>='0' && ch[2]<='5') if(ch[3]>='0' && ch[3]<='9')
    {
        hour=atoi(ch); min=atoi(&ch[2]); ok=1;
    }

    // xx:xx
    if(len==5) if(ch[0]>='0' && ch[0]<='2') if(ch[1]>='0' && ch[1]<='9') if(ch[2]==':') if(ch[3]>='0' && ch[3]<='5') if(ch[4]>='0' && ch[4]<='9')
    {
        hour=atoi(ch); min=atoi(&ch[3]); ok=1;
    }

    // dayx:xx
    if(len==7) if(ch[3]>='0' && ch[3]<='9') if(ch[4]==':') if(ch[5]>='0' && ch[5]<='5') if(ch[6]>='0' && ch[6]<='9')
    {
        if(strstr(ch,"lun")) day=1;
        if(strstr(ch,"mar")) day=2;
        if(strstr(ch,"mer")) day=3;
        if(strstr(ch,"jeu")) day=4;
        if(strstr(ch,"ven")) day=5;
        if(strstr(ch,"sam")) day=6;
        if(strstr(ch,"dim")) day=7;

        if(day!=0) { hour=atoi(&ch[3]); min=atoi(&ch[5]); ok=1; }
    }

    // dayxx:xx
    if(len==8) if(ch[3]>='0' && ch[3]<='2') if(ch[4]>='0' && ch[4]<='9') if(ch[5]==':') if(ch[6]>='0' && ch[6]<='5') if(ch[7]>='0' && ch[7]<='9')
    {
        if(strstr(ch,"lun")) day=1;
        if(strstr(ch,"mar")) day=2;
        if(strstr(ch,"mer")) day=3;
        if(strstr(ch,"jeu")) day=4;
        if(strstr(ch,"ven")) day=5;
        if(strstr(ch,"sam")) day=6;
        if(strstr(ch,"dim")) day=7;

        if(day!=0) { hour=atoi(&ch[3]); min=atoi(&ch[6]); ok=1; }
    }


    *val=(day<<13)+(hour<<8)+min;

    return ok;
}


/*------------------------------------------------------------------------------
NAME  : decompose_ex
DESCR : decompose the specified string and add type and adr/val
ARG   : szStr: string to decomose
RETURN: substring decomposition number
------------------------------------------------------------------------------*/
int decompose_ex(char* szStr)
{
    int i;
    int ret;
    int val;
    int type;
    char c;

    ret=decompose(szStr);

    for(i=0;i<=SIZE_DECOMPOSE;i++) decomposed_string_type[i]=TYPE_NOTHING;
    for(i=0;i<ret;i++)             decomposed_string_type[i]=TYPE_UNKNOWN;

    for(i=0;i<ret;i++)
    {
        c=decomposed_string[i][0];

        if(decomposed_string[i][1]=='\0')
        if(c=='=' || c=='*' || c=='+' || c=='-' || c=='&' || c=='|' || c=='^' || c=='$' || c=='�' || c=='[' || c==']' || c=='(' || c== ')'
        || c=='{' || c=='}' || c=='/' || c=='\\'|| c=='\''|| c=='\"'|| c=='!' || c=='?' || c=='~' || c=='>' || c=='<' || c=='#'
        || c=='\n'|| c=='\r'|| c=='.' || c==':' || c==',' || c==';' || c=='%' )
        { decomposed_string_type[i]=TYPE_OP; decomposed_string_adrval[i]=decomposed_string[i][0]; }

        if(is_lit(decomposed_string[i])) { decomposed_string_type[i]=TYPE_LIT; decomposed_string_adrval[i]=atoi(decomposed_string[i]); }

        if(is_date(decomposed_string[i],&val)) { decomposed_string_type[i]=TYPE_LIT; decomposed_string_adrval[i]=val; }

        if(var_adr_get(decomposed_string[i],&val,&type))
        {
            if(type==VARTYPE_ZB)   { decomposed_string_type[i]=TYPE_ZB;   decomposed_string_adrval[i]=val; }
            if(type==VARTYPE_ZV8)  { decomposed_string_type[i]=TYPE_ZV8;  decomposed_string_adrval[i]=val+0x80; }
            if(type==VARTYPE_ZV16) { decomposed_string_type[i]=TYPE_ZV16; decomposed_string_adrval[i]=val; }
        }

    }

    return ret;
}


/*------------------------------------------------------------------------------
NAME  : decompose_remove_col
DESCR : remove indicated decompose column
ARG   : col: column to remove
RETURN: None (decomposed_string...)
------------------------------------------------------------------------------*/
void decompose_remove_col(int col)
{
    int i;

    for(i=col;i<=(SIZE_DECOMPOSE-2);i++)
	{
		strcpy(decomposed_string[i],decomposed_string[i+1]);
		decomposed_string_type[i]=decomposed_string_type[i+1];
		decomposed_string_adrval[i]=decomposed_string_adrval[i+1];
		decomposed_string_inv[i]=decomposed_string_inv[i+1];
		decomposed_string_oldedge[i]=decomposed_string_oldedge[i+1];
	}

}


/*------------------------------------------------------------------------------
NAME  : decompose_ex2
DESCR : add inv and edge/old ZB informations after decompose_ex 
ARG   : None (work on decomposed_string)
RETURN: None (decomposed_string_inv & decomposed_string_oldedge)
------------------------------------------------------------------------------*/
int decompose_ex2(char* szStr)
{
    int i,ok,ret;

    ret=decomposed_string_nb; //decompose(szStr);

    for(i=0;i<SIZE_DECOMPOSE;i++) decomposed_string_inv[i]=TYPE_NOTINV;
    for(i=0;i<SIZE_DECOMPOSE;i++) decomposed_string_oldedge[i]=TYPE_ZBNEW;

	do
	{
		ok=0;
	    i=0;
	    while(i<decomposed_string_nb)
		{
		    if((i+1)<decomposed_string_nb) if(decomposed_string_type[i+1]==TYPE_ZB)
    		if(decomposed_string_type[i]==TYPE_OP) if(decomposed_string_adrval[i]=='!')
			{
                decomposed_string_inv[i+1]=TYPE_INV; 
    			decompose_remove_col(i);
				decomposed_string_nb--;
	    		ok=1; break;
			}

    		if(decomposed_string_type[i]==TYPE_ZB)
            if((i+1)<decomposed_string_nb) if(decomposed_string_type[i+1]==TYPE_OP)
			{
		   	    if(decomposed_string_adrval[i+1]=='�') 
				{
			        decomposed_string_oldedge[i]=TYPE_ZBOLD;
    				decompose_remove_col(i+1);
    				decomposed_string_nb--;
	    		    ok=1; break;
				}
    			if(decomposed_string_adrval[i+1]=='/') 
				{
			        decomposed_string_oldedge[i]=TYPE_ZBUP;
    				decompose_remove_col(i+1);
					decomposed_string_nb--;
        		    ok=1; break;
				}
    			if(decomposed_string_adrval[i+1]=='\\') 
				{
			        decomposed_string_oldedge[i]=TYPE_ZBDOWN;
    				decompose_remove_col(i+1);
					decomposed_string_nb--;
        		    ok=1; break;
				}
			}

            i++;
		}
	}
	while(ok==1);
}


/*------------------------------------------------------------------------------
NAME  : decompose_debug
DESCR : display decomposed substring
ARG   : None
RETURN: none
------------------------------------------------------------------------------*/
void decompose_debug(void)
{
   int i;
   char szTemp[1000];
   char szType[1000];
   char szInv[1000];
   char szOldEdge[1000];


   strcpy(szError,"");
   strcpy(szTemp,"");
   for(i=0;i<decomposed_string_nb;i++)
   {
       strcpy(szType,"");
       if(decomposed_string_type[i]==TYPE_NOTHING  ) strcpy(szType,"NOT"     );
       if(decomposed_string_type[i]==TYPE_UNKNOWN  ) strcpy(szType,"UNK"     );
       if(decomposed_string_type[i]==TYPE_LIT      ) strcpy(szType,"LIT"     );
       if(decomposed_string_type[i]==TYPE_ZB       ) strcpy(szType,"ZB"      );
       if(decomposed_string_type[i]==TYPE_ZV8      ) strcpy(szType,"ZV8"     );
       if(decomposed_string_type[i]==TYPE_ZV16     ) strcpy(szType,"ZV16"    );
       if(decomposed_string_type[i]==TYPE_OP       ) strcpy(szType,"OP"      );
       strcpy(szInv,"");
       if(decomposed_string_inv[i]==TYPE_NOTINV    ) strcpy(szInv,""         );
       if(decomposed_string_inv[i]==TYPE_INV       ) strcpy(szInv,"INV"      );
       strcpy(szOldEdge,"");
       if(decomposed_string_oldedge[i]==TYPE_ZBNEW ) strcpy(szOldEdge,""     );
       if(decomposed_string_oldedge[i]==TYPE_ZBOLD ) strcpy(szOldEdge,"OLD"  );
       if(decomposed_string_oldedge[i]==TYPE_ZBUP  ) strcpy(szOldEdge,"UP"   );
       if(decomposed_string_oldedge[i]==TYPE_ZBDOWN) strcpy(szOldEdge,"DOWN" );

       sprintf(szTemp,"%s(%s,%s,%s,%d) ",decomposed_string[i],szType,szInv,szOldEdge,decomposed_string_adrval[i]);
       strcat(szError,szTemp);
   }

   if(EN_DISP_DECOMPOSE) ErrorScreen.add(szError);

   if(lit_put_eq) fprintf(pf_lit,"\n%s\n",szError);
}


/*------------------------------------------------------------------------------
NAME  : load_gra_mem
DESCR : load the (@gra section of) .gra file in memory
ARG   : szSectName: section to load
RETURN: 0: cannot open definition file
        1: ok
        2: other pb
NOTES: remove comments
       replace tab
------------------------------------------------------------------------------*/
int load_gra_mem(char* szSectName)
{
    int j,i,k;
    FILE* pf;
    char c,cnext;
    char sz[100];
    int comment_start_stop=0,comment_eol=0,sect_ok=0;
    int get2=0,end=0;


    //1. initialize the memory with spaces
    for(j=0;j<GRA_MEM_ROW;j++) for(i=0;i<GRA_MEM_COL;i++) gra_mem[j][i]=' ';

    //2. load file in memory
    j=0;
    i=-1;

    pf=fopen(szGraFileName,"rt");
    if(pf==NULL) return 0;
    c=cnext=' ';
    while(end==0)
    {
                   c=cnext; if(fscanf(pf,"%c",&cnext)==EOF) { end=1; cnext=' '; }
        if(get2) { c=cnext; if(fscanf(pf,"%c",&cnext)==EOF) { end=1; cnext=' '; } get2=0; }

        // gestion des sauts de ligne
        if(c=='\n') { j++; i=-1; comment_eol=0; continue; }
        if(c=='\r') continue;
        i++;

        // gestion des sections (prioritaire par rapport aux commentaires)
        if(c=='@')
        {
            if(fscanf(pf,"%s",&sz[1])==EOF) break; sz[0]=cnext; get2=1; strlwr(sz);
            sect_ok=0;comment_start_stop=0;comment_eol=0;
            if(STR_SAME strcmp(sz,szSectName)) sect_ok=1;
            continue;
        }
        if(sect_ok==0) continue;

        // gestion des commentaires
        if(comment_start_stop==0 && comment_eol==0)
        {
            if(c=='/' && cnext=='*') { comment_start_stop=1; get2=1; continue; }
            if(c=='/' && cnext=='/') { comment_eol=1;        get2=1; continue; }
        }
        if(comment_start_stop==1) if(c=='*' && cnext=='/') { comment_start_stop=0; get2=1; continue; }

        if(comment_start_stop || comment_eol) continue;

        // gestion des tabulations
        if(c=='\t')
        {
            for(k=0;k<SpaceByTab;k++) { if(j<GRA_MEM_ROW && i<GRA_MEM_COL) gra_mem[j][i]=' '; i++; }
            continue;
        }

        // gestion des caracteres a inserer
        gra_mem[j][i]=c;
    }
    fclose(pf);

    //3. verify
    pf=NULL;
    if(STR_SAME strcmp(szSectName,"gra" )) pf=fopen("verif_gra_mem.txt","wt");
    if(STR_SAME strcmp(szSectName,"pre" )) pf=fopen("verif_pre_mem.txt","wt");
    if(STR_SAME strcmp(szSectName,"post")) pf=fopen("verif_post_mem.txt","wt");
    if(pf)
    {
        for(j=0;j<GRA_MEM_ROW;j++)
        {
            for(i=0;i<GRA_MEM_COL;i++) fprintf(pf,"%c",gra_mem[j][i]);
            fprintf(pf,"\n");
        }
        fclose(pf);
    }

    return 1;
}


/*------------------------------------------------------------------------------
NAME  : AddLitHex(char* LitOp, char* LitVar, int HexOp, int HexVar)
DESCR : Add instruction to the lit file and to the hex array
ARG   : char* LitOp : Lit operation
        char* LitVar: Lit var name
        int HexOp   : Hex op code (number)
        int HexVar  : Hex var code (number)
RETURN: None
NOTES:
------------------------------------------------------------------------------*/
/*
;=================================================================================
;
; INSTRUCTIONS GRAPHCET
;
;=================================================================================
;
;           ORDRE                    VAL     ORDRE16|VAL16 (existe si ORDRE.7)
;
;           76543210
;
; op std    00   000   nop   .       NA        x x               0
; (seq+bit) 00   001   eti   *       ZB        x x               1
;           00   010   et    -       ZB        x x               2
;           00   011   va    >       ZB        x x               3
;           00   100   ega   =       ZB        x x               4
;           00   101   set   s       ZB        x x               5
;           00   110   clr   c       ZB        x x               6
;           00   111   end   !       NA        x x               7
;
; tst bit   01neo 00   l             ZB        x x               40 + 20 pour n + 0 new
;           01neo 01   a             ZB        x x               41             + 8 old
;           01neo 10   o             ZB        x x               42             + 10 up
;           01neo 11   x             ZB        x x               43             + 18 down
;
; tstvar    11n=<>00   ltstvar       VAR       x8/16 bis val     80 + 20 pour n + 10 =
;           11n=<>01   atstvar       VAR       x8/16 bis val     81             +  8 <
;           11n=<>10   otstvar       VAR       x8/16 bis val     82             +  4 >
;           11n=<>11   xtstvar       VAR       x8/16 bis val     83
;
; op  var   10    00   =var          VAR       x8/16 bis val     C0
;           10    01   +var          VAR       x8/16 bis val     C1
;           10    10   -var          VAR       x8/16 bis val     C2
;           10    11   res (clr)     VAR       x8/16 bis val     C3
;
; si VAR>0x80 alors vaiable 8 bits   0x80+VAR   0 8 nits val 
;
;
;n=inversion (ex: ln,xtstvarn ...)
;o=old zb
;e=edge
;eo
;00 new ZB
;01 old ZB
;10 /   ZB
;11 \   ZB
;
;
;
*/
#define INST_NOP      0x00
#define INST_ETAI     0x01
#define INST_ET       0x02
#define INST_VA       0x03
#define INST_EGA      0x04
#define INST_EGASET   0x05
#define INST_EGACLR   0x06
#define INST_END      0x07

#define INST_LOAD     0x40
#define INST_AND      0x41
#define INST_OR       0x42
#define INST_XOR      0x43

#define INST_LOADVAR  0xC0
#define INST_ANDVAR   0xC1
#define INST_ORVAR    0xC2
#define INST_XORVAR   0xC3

#define INST_OPVAREGA 0x80
#define INST_OPVARADD 0x81
#define INST_OPVARSUB 0x82

#define INST_NOT      0x20
#define INST_OLD      0x08
#define INST_UP       0x10
#define INST_DOWN     0x18
#define INST_EGAEGA   0x10
#define INST_SUPEGA   0x14
#define INST_INFEGA   0x18
#define INST_INFSUP   0x0C
#define INST_INF      0x08
#define INST_SUP      0x04


void AddLitHex(char* LitOp, char* LitVar, int HexOp, int HexVar)
{
    fprintf(pf_lit,"%-4s %-20s [%02x,%02x]\n",LitOp,LitVar,HexOp,HexVar);
    hex_gra[hex_gra_ind++]=HexOp; hex_gra[hex_gra_ind++]=HexVar;
}
void AddLitHexLit(char* LitOp, char* LitVar, int HexOp, int HexVar, int Lit)
{
    int lith,litl;

    lith=(Lit>>8)&0xff;
    litl=Lit&0xff;

    fprintf(pf_lit,"%-4s %-20s [%02x,%02x][%02x,%02x]\n",LitOp,LitVar,HexOp,HexVar,lith,litl);
    hex_gra[hex_gra_ind++]=HexOp; hex_gra[hex_gra_ind++]=HexVar;
    hex_gra[hex_gra_ind++]=lith;  hex_gra[hex_gra_ind++]=litl;
}
void AddLit(char* szStr)
{
     fprintf(pf_lit,"%s\n",szStr);
}


/*------------------------------------------------------------------------------
NAME  : FillHexFile
DESCR : fill hex file with interpretor code from hex_line array (from .def)
        and graphcet code from hex_gra array
ARG   : None
RETURN: None
NOTES:
        if(fscanf(pf," %c",&c)==EOF) break; //remove :
        fscanf(pf," %02x",&nb_word); nb_word=nb_word/2;
        fscanf(pf," %04x",&adr); adr=adr/2;
        fscanf(pf," %02x",&op);

        if(op==0) for(i=0;i<nb_word;i++)
        {
            fscanf(pf," %02x",&datl);
            fscanf(pf," %02x",&dath);
            table[adr+i]=(dath<<8)+datl;
        }

        fscanf(pf," %02x",&sum);
------------------------------------------------------------------------------*/
void FillHexFile(void)
{
    int i;
    int instr,var,adr,sum;
    int adrh,adrl;
    int get=1;


    for(i=0;i<hex_ind;i++)
    {
        if(STR_SAME stricmp(hex_line[i],":00000001FF")) get=0;
        if(STR_SAME stricmp(hex_line[i],":04100000073400347D")) get=0;
        if(get) fprintf(pf_hex,"%s\n",hex_line[i]);
    }

    for(i=0;i<hex_gra_ind;i+=2)
    {
        instr=hex_gra[i];
        var=hex_gra[i+1];
        adr=2*(def_ZG_START+i);
        adrh=(adr>>8)&0xff;
        adrl=adr&0xff;
        sum=4+adrh+adrl+0+0x34+instr+0x34+var;
        sum=(256-(sum&0xff))&0xff;

        fprintf(pf_hex,":04%04X00%02X%02X%02X%02X%02X\n",adr,instr,0x34,var,0x34,sum);
    }

    fprintf(pf_hex,":00000001FF\n"); // end indicator
}

/*------------------------------------------------------------------------------
NAME  : process_equation
DESCR : process the given equation
ARG   : szEq: equation string
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int process_equation(char* szEq)
{
    char szTemp[255];
    char szTemp2[255];
    char szTemp3[255];
    int ind,inc,ok,is8_16,start;
    int instr;

    sprintf(szTemp,"eq: %s",szEq); ErrorScreen.addeqres(szTemp);

    decompose_ex(szEq);
	decompose_ex2(szEq);
   	decompose_debug();

     ///*UU*/ ErrorScreen.add("Exit from process_equation");  return 1;

    ind=0;
	start=1;
    while(1)
    {
        inc=1;
        ok=0;

        if(decomposed_string_type[ind]==TYPE_NOTHING) { ok=1; break; }

        // et, etai, va    *,-,>
        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]=='*' || decomposed_string_adrval[ind]=='-' || decomposed_string_adrval[ind]=='>')
        if(decomposed_string_type[ind+1]==TYPE_ZB)
        {
			start=0;
            ok=1; inc=2;
			if(decomposed_string_adrval[ind]=='*') AddLitHex("*", decomposed_string[ind+1] ,INST_ETAI, decomposed_string_adrval[ind+1]);
			if(decomposed_string_adrval[ind]=='-') AddLitHex("-", decomposed_string[ind+1] ,INST_ET  , decomposed_string_adrval[ind+1]);
			if(decomposed_string_adrval[ind]=='>') AddLitHex(">", decomposed_string[ind+1] ,INST_VA  , decomposed_string_adrval[ind+1]);
        }

        // first ZB
        if(decomposed_string_type[ind]==TYPE_ZB) if(start)
        {
			start=0;
            ok=1; inc=1;
			strcpy(szTemp,"");
			if(decomposed_string_inv[ind]==TYPE_NOTINV) {strcat(szTemp,"l"); instr=INST_LOAD; } else { strcat(szTemp,"ln"); instr=INST_LOAD | INST_NOT; }
			if(decomposed_string_oldedge[ind]==TYPE_ZBOLD ) {instr|=INST_OLD; strcat(szTemp,"�");}
			if(decomposed_string_oldedge[ind]==TYPE_ZBUP  ) {instr|=INST_UP;  strcat(szTemp,"/");}
			if(decomposed_string_oldedge[ind]==TYPE_ZBDOWN) {instr|=INST_DOWN;strcat(szTemp,"\\");}
            AddLitHex(szTemp ,decomposed_string[ind] ,instr  , decomposed_string_adrval[ind]);
		}

        // first ZV  ==,>=,<= or >,< or <>
        if(decomposed_string_type[ind]==TYPE_ZV8 || decomposed_string_type[ind]==TYPE_ZV16) if(start)
        if(decomposed_string_type[ind+1]==TYPE_OP) if(decomposed_string_adrval[ind+1]=='=' || decomposed_string_adrval[ind+1]=='<' || decomposed_string_adrval[ind+1]=='>')
        if(decomposed_string_type[ind+2]==TYPE_OP) if(decomposed_string_adrval[ind+2]=='=')
        if(decomposed_string_type[ind+3]==TYPE_LIT)
        {
			start=0;
            ok=1; inc=4;
			if(decomposed_string_type[ind]==TYPE_ZV8) is8_16=8; else is8_16=16;
			if(decomposed_string_inv[ind]==TYPE_NOTINV) {strcpy(szTemp,"l"); instr=INST_LOADVAR;} else {strcpy(szTemp,"ln"); instr=INST_LOADVAR | INST_NOT; }
            if(decomposed_string_adrval[ind+1]=='=') { strcpy(szTemp3,"=="); instr|=INST_EGAEGA; }
            if(decomposed_string_adrval[ind+1]=='>') { strcpy(szTemp3,">="); instr|=INST_SUPEGA; }
            if(decomposed_string_adrval[ind+1]=='<') { strcpy(szTemp3,"<="); instr|=INST_INFEGA; }
			sprintf(szTemp2,"%s%s%d",decomposed_string[ind],szTemp3,decomposed_string_adrval[ind+3]);
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind], decomposed_string_adrval[ind+3]);
		}

        if(decomposed_string_type[ind]==TYPE_ZV8 || decomposed_string_type[ind]==TYPE_ZV16) if(start)
        if(decomposed_string_type[ind+1]==TYPE_OP) if(decomposed_string_adrval[ind+1]=='<')
        if(decomposed_string_type[ind+2]==TYPE_OP) if(decomposed_string_adrval[ind+2]=='>')
        if(decomposed_string_type[ind+3]==TYPE_LIT)
        {
			start=0;
            ok=1; inc=4;
			if(decomposed_string_type[ind]==TYPE_ZV8) is8_16=8; else is8_16=16;
			if(decomposed_string_inv[ind]==TYPE_NOTINV) {strcpy(szTemp,"l"); instr=INST_LOADVAR;} else {strcpy(szTemp,"ln");  instr=INST_LOADVAR | INST_NOT;}
            sprintf(szTemp2,"%s<>%d",decomposed_string[ind],decomposed_string_adrval[ind+3]);
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind], decomposed_string_adrval[ind+3]);
		}

        if(decomposed_string_type[ind]==TYPE_ZV8 || decomposed_string_type[ind]==TYPE_ZV16) if(start)
        if(decomposed_string_type[ind+1]==TYPE_OP) if(decomposed_string_adrval[ind+1]=='<' || decomposed_string_adrval[ind+1]=='>')
        if(decomposed_string_type[ind+2]==TYPE_LIT)
        {
			start=0;
            ok=1; inc=3;
			if(decomposed_string_type[ind]==TYPE_ZV8) is8_16=8; else is8_16=16;
			if(decomposed_string_inv[ind]==TYPE_NOTINV) { strcpy(szTemp ,"l"); instr=INST_LOADVAR;} else {strcpy(szTemp,"ln");   instr=INST_LOADVAR | INST_NOT;}
            if(decomposed_string_adrval[ind+1]=='>')    { strcpy(szTemp3,">"); instr|=INST_SUP; }
            if(decomposed_string_adrval[ind+1]=='<')    { strcpy(szTemp3,"<"); instr|=INST_INF; }
			sprintf(szTemp2,"%s%s%d",decomposed_string[ind],szTemp3,decomposed_string_adrval[ind+2]);
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind], decomposed_string_adrval[ind+2]);
		}

		start=0;

        // Next ZB  .,|,^, or =, or =set or =clr
        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]=='.' || decomposed_string_adrval[ind]=='|' || decomposed_string_adrval[ind]=='^' )
        if(decomposed_string_type[ind+1]==TYPE_ZB)
		{
            ok=1; inc=2;
			if(decomposed_string_adrval[ind]=='.') { strcpy(szTemp,"a"); instr=INST_AND; }
			if(decomposed_string_adrval[ind]=='|') { strcpy(szTemp,"o"); instr=INST_OR;  }
			if(decomposed_string_adrval[ind]=='^') { strcpy(szTemp,"x"); instr=INST_XOR; }
			if(decomposed_string_inv[ind+1]==TYPE_NOTINV) strcat(szTemp,""); else { strcat(szTemp,"n"); instr|=INST_NOT; }
			if(decomposed_string_oldedge[ind+1]==TYPE_ZBOLD ) {instr|=INST_OLD; strcat(szTemp,"�");}
			if(decomposed_string_oldedge[ind+1]==TYPE_ZBUP  ) {instr|=INST_UP;  strcat(szTemp,"/");}
			if(decomposed_string_oldedge[ind+1]==TYPE_ZBDOWN) {instr|=INST_DOWN;strcat(szTemp,"\\");}
            AddLitHex(szTemp ,decomposed_string[ind+1] ,instr  , decomposed_string_adrval[ind+1]);
		}

        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]=='=')
        if(decomposed_string_type[ind+1]==TYPE_ZB)
		{
            ok=1; inc=2;
            AddLitHex("=",decomposed_string[ind+1] ,INST_EGA, decomposed_string_adrval[ind+1]);
		}

        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]=='=')
        if(decomposed_string_type[ind+1]==TYPE_UNKNOWN) if(STR_SAME stricmp(decomposed_string[ind+1],"set") || STR_SAME stricmp(decomposed_string[ind+1],"s"))
        if(decomposed_string_type[ind+2]==TYPE_ZB)
		{
            ok=1; inc=3;
            AddLitHex("=set",decomposed_string[ind+2] ,INST_EGASET, decomposed_string_adrval[ind+2]);
		}

        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]=='=')
        if(decomposed_string_type[ind+1]==TYPE_UNKNOWN) if(STR_SAME stricmp(decomposed_string[ind+1],"clr") || STR_SAME stricmp(decomposed_string[ind+1],"clear") || STR_SAME stricmp(decomposed_string[ind+1],"c"))
        if(decomposed_string_type[ind+2]==TYPE_ZB)
		{
            ok=1; inc=3;
            AddLitHex("=clr",decomposed_string[ind+2] ,INST_EGASET, decomposed_string_adrval[ind+2]);
		}

        // Next ZV  .,|,^ for ==,>=,<=    or    .,|,^ for >,<    or    .,|,^ for <>    or     =op v=lit    or    =op v+/-lit    or    =op v++/v--
        if(decomposed_string_type[ind]==TYPE_OP)  if(decomposed_string_adrval[ind]=='.' || decomposed_string_adrval[ind]=='|' || decomposed_string_adrval[ind]=='^' )
        if(decomposed_string_type[ind+1]==TYPE_ZV8 || decomposed_string_type[ind+1]==TYPE_ZV16)
        if(decomposed_string_type[ind+2]==TYPE_OP) if(decomposed_string_adrval[ind+2]=='=' || decomposed_string_adrval[ind+2]=='<' || decomposed_string_adrval[ind+2]=='>')
        if(decomposed_string_type[ind+3]==TYPE_OP) if(decomposed_string_adrval[ind+3]=='=')
        if(decomposed_string_type[ind+4]==TYPE_LIT)
		{
            is8_16=8;
            if(decomposed_string_type[ind+1]==TYPE_ZV16) is8_16=16;

            ok=1; inc=5;
			if(decomposed_string_adrval[ind]=='.') { strcpy(szTemp,"a"); instr=INST_ANDVAR; }
			if(decomposed_string_adrval[ind]=='|') { strcpy(szTemp,"o"); instr=INST_ORVAR;  }
			if(decomposed_string_adrval[ind]=='^') { strcpy(szTemp,"x"); instr=INST_XORVAR; }
			if(decomposed_string_inv[ind+1]==TYPE_NOTINV) strcat(szTemp,""); else { strcat(szTemp,"n"); instr|=INST_NOT; }
            if(decomposed_string_adrval[ind+2]=='=') { strcpy(szTemp3,"=="); instr|=INST_EGAEGA; }
            if(decomposed_string_adrval[ind+2]=='>') { strcpy(szTemp3,">="); instr|=INST_SUPEGA; }
            if(decomposed_string_adrval[ind+2]=='<') { strcpy(szTemp3,"<="); instr|=INST_INFEGA; }
			sprintf(szTemp2,"%s%s%d",decomposed_string[ind+1],szTemp3,decomposed_string_adrval[ind+4]);
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind+1], decomposed_string_adrval[ind+4]);
		}

        if(decomposed_string_type[ind]==TYPE_OP)  if(decomposed_string_adrval[ind]=='.' || decomposed_string_adrval[ind]=='|' || decomposed_string_adrval[ind]=='^' )
        if(decomposed_string_type[ind+1]==TYPE_ZV8 || decomposed_string_type[ind+1]==TYPE_ZV16)
        if(decomposed_string_type[ind+2]==TYPE_OP) if(decomposed_string_adrval[ind+2]=='<')
        if(decomposed_string_type[ind+3]==TYPE_OP) if(decomposed_string_adrval[ind+3]=='>')
        if(decomposed_string_type[ind+4]==TYPE_LIT)
		{
            is8_16=8;
            if(decomposed_string_type[ind+1]==TYPE_ZV16) is8_16=16;

            ok=1; inc=5;
			if(decomposed_string_adrval[ind]=='.') { strcpy(szTemp,"a"); instr=INST_ANDVAR; }
			if(decomposed_string_adrval[ind]=='|') { strcpy(szTemp,"o"); instr=INST_ORVAR;  }
			if(decomposed_string_adrval[ind]=='^') { strcpy(szTemp,"x"); instr=INST_XORVAR; }
			if(decomposed_string_inv[ind+1]==TYPE_NOTINV) strcat(szTemp,""); else { strcat(szTemp,"n"); instr|=INST_NOT; }
            instr|=INST_INFSUP;
			sprintf(szTemp2,"%s%s%d",decomposed_string[ind+1],"<>",decomposed_string_adrval[ind+4]);
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind+1], decomposed_string_adrval[ind+4]);
		}

        if(decomposed_string_type[ind]==TYPE_OP)  if(decomposed_string_adrval[ind]=='.' || decomposed_string_adrval[ind]=='|' || decomposed_string_adrval[ind]=='^' )
        if(decomposed_string_type[ind+1]==TYPE_ZV8 || decomposed_string_type[ind+1]==TYPE_ZV16)
        if(decomposed_string_type[ind+2]==TYPE_OP) if(decomposed_string_adrval[ind+2]=='<' || decomposed_string_adrval[ind+3]=='>')
        if(decomposed_string_type[ind+3]==TYPE_LIT)
		{
            ok=1; inc=4;

            is8_16=8;
            if(decomposed_string_type[ind+1]==TYPE_ZV16) is8_16=16;

			if(decomposed_string_adrval[ind]=='.') { strcpy(szTemp,"a"); instr=INST_ANDVAR; }
			if(decomposed_string_adrval[ind]=='|') { strcpy(szTemp,"o"); instr=INST_ORVAR;  }
			if(decomposed_string_adrval[ind]=='^') { strcpy(szTemp,"x"); instr=INST_XORVAR; }
			if(decomposed_string_inv[ind+1]==TYPE_NOTINV) strcat(szTemp,""); else { strcat(szTemp,"n"); instr|=INST_NOT; }
            if(decomposed_string_adrval[ind+2]=='>') { strcpy(szTemp3,">"); instr|=INST_SUP; }
            if(decomposed_string_adrval[ind+2]=='<') { strcpy(szTemp3,"<"); instr|=INST_INF; }
			sprintf(szTemp2,"%s%s%d",decomposed_string[ind+1],szTemp3,decomposed_string_adrval[ind+3]);
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind+1], decomposed_string_adrval[ind+3]);
		}

        if(decomposed_string_type[ind]==TYPE_OP)  if(decomposed_string_adrval[ind]=='=')
        if(decomposed_string_type[ind+1]==TYPE_UNKNOWN) if(STR_SAME stricmp(decomposed_string[ind+1],"op"))
        if(decomposed_string_type[ind+2]==TYPE_ZV8 || decomposed_string_type[ind+2]==TYPE_ZV16)
        if(decomposed_string_type[ind+3]==TYPE_OP)  if(decomposed_string_adrval[ind+3]=='=' || decomposed_string_adrval[ind+3]=='+' || decomposed_string_adrval[ind+3]=='-' )
        if(decomposed_string_type[ind+4]==TYPE_LIT)
		{
            ok=1; inc=5;

            is8_16=8;
            if(decomposed_string_type[ind+2]==TYPE_ZV16) is8_16=16;

       		if(decomposed_string_adrval[ind+3]=='=') { sprintf(szTemp,"=op"); sprintf(szTemp2,"%s=%d",decomposed_string[ind+2],decomposed_string_adrval[ind+4]); instr=INST_OPVAREGA; }
    		if(decomposed_string_adrval[ind+3]=='+') { sprintf(szTemp,"=op"); sprintf(szTemp2,"%s+%d",decomposed_string[ind+2],decomposed_string_adrval[ind+4]); instr=INST_OPVARADD; }
    		if(decomposed_string_adrval[ind+3]=='-') { sprintf(szTemp,"=op"); sprintf(szTemp2,"%s-%d",decomposed_string[ind+2],decomposed_string_adrval[ind+4]); instr=INST_OPVARSUB; }
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind+2], decomposed_string_adrval[ind+4]);
		}

        if(decomposed_string_type[ind]==TYPE_OP)  if(decomposed_string_adrval[ind]=='=')
        if(decomposed_string_type[ind+1]==TYPE_UNKNOWN) if(STR_SAME stricmp(decomposed_string[ind+1],"op"))
        if(decomposed_string_type[ind+2]==TYPE_ZV8 || decomposed_string_type[ind+2]==TYPE_ZV16)
        if(decomposed_string_type[ind+3]==TYPE_OP) if(decomposed_string_type[ind+4]==TYPE_OP)
        if((decomposed_string_adrval[ind+3]=='+' && decomposed_string_adrval[ind+4]=='+') || (decomposed_string_adrval[ind+3]=='-' && decomposed_string_adrval[ind+4]=='-') )
		{
            ok=1; inc=5;

            is8_16=8;
            if(decomposed_string_type[ind+2]==TYPE_ZV16) is8_16=16;

    		if(decomposed_string_adrval[ind+3]=='+') { sprintf(szTemp,"=op");  sprintf(szTemp2,"%s+1",decomposed_string[ind+2]); instr==INST_OPVARADD; }
    		if(decomposed_string_adrval[ind+3]=='-') { sprintf(szTemp,"=op");  sprintf(szTemp2,"%s-1",decomposed_string[ind+2]); instr==INST_OPVARSUB; }
            AddLitHexLit(szTemp ,szTemp2 ,instr  , decomposed_string_adrval[ind+2], 1);
		}


        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]==',')
        {
            ok=1; inc=1; start=1;
        }

        ind+=inc;

        if(ok==0) { CompileError++; sprintf(szTemp,"Line %3d: Error in equation: %s",CurrLine+1,szEq); ErrorScreen.add(szTemp); break;}
    }

    return ok;
}


/*------------------------------------------------------------------------------
NAME  : process_equation_out
DESCR : process the given equation for output
ARG   : szEq: equation string
        et  : etape
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/

char OutEqZb_str[100][50];
int  OutEqZb_adrval[100];
int  OutEqZb_ind;
int  OutEqZb_et[100];
int  OutEqZb_type[100];

#define TYPE_NORM 0
#define TYPE_SET  1
#define TYPE_CLR  2

void process_equation_out_init(void)
{
    OutEqZb_ind=0;
}

void process_equation_out_rest(void)
{
    int i,j;
    char szTemp[100];

    for(i=0;i<OutEqZb_ind;i++) if(OutEqZb_et[i]!=-1) if(OutEqZb_type[i]==TYPE_NORM)
    {
        sprintf(szTemp,"x%d",OutEqZb_et[i]);
        AddLitHex("l",szTemp ,INST_LOAD  ,OutEqZb_et[i]);
        OutEqZb_et[i]=-1;

        for(j=0;j<OutEqZb_ind;j++) if(i!=j) if(OutEqZb_type[j]==TYPE_NORM) if(STR_SAME stricmp(OutEqZb_str[i],OutEqZb_str[j]))
        {
            sprintf(szTemp,"x%d",OutEqZb_et[j]);
            AddLitHex("o",szTemp ,INST_OR  ,OutEqZb_et[j]);
            OutEqZb_et[j]=-1;
        }

        AddLitHex("=" ,OutEqZb_str[i] ,INST_EGA  ,OutEqZb_adrval[i]);
    }

    for(i=0;i<OutEqZb_ind;i++) if(OutEqZb_et[i]!=-1) if(OutEqZb_type[i]==TYPE_SET)
    {
        sprintf(szTemp,"x%d",OutEqZb_et[i]);
        AddLitHex("l",szTemp ,INST_LOAD  ,OutEqZb_et[i]);
        OutEqZb_et[i]=-1;

        for(j=0;j<OutEqZb_ind;j++) if(i!=j) if(OutEqZb_type[j]==TYPE_SET) if(STR_SAME stricmp(OutEqZb_str[i],OutEqZb_str[j]))
        {
            sprintf(szTemp,"x%d",OutEqZb_et[j]);
            AddLitHex("o",szTemp ,INST_OR  ,OutEqZb_et[j]);
            OutEqZb_et[j]=-1;
        }

        AddLitHex("=set" ,OutEqZb_str[i] ,INST_EGASET  ,OutEqZb_adrval[i]);
    }

    for(i=0;i<OutEqZb_ind;i++) if(OutEqZb_et[i]!=-1) if(OutEqZb_type[i]==TYPE_CLR)
    {
        sprintf(szTemp,"x%d",OutEqZb_et[i]);
        AddLitHex("l",szTemp ,INST_LOAD  ,OutEqZb_et[i]);
        OutEqZb_et[i]=-1;

        for(j=0;j<OutEqZb_ind;j++) if(i!=j) if(OutEqZb_type[j]==TYPE_CLR) if(STR_SAME stricmp(OutEqZb_str[i],OutEqZb_str[j]))
        {
            sprintf(szTemp,"x%d",OutEqZb_et[j]);
            AddLitHex("o",szTemp ,INST_OR  ,OutEqZb_et[j]);
            OutEqZb_et[j]=-1;
        }

        AddLitHex("=clr" ,OutEqZb_str[i] ,INST_EGACLR  ,OutEqZb_adrval[i]);
    }
}

int process_equation_out(char* szEq, int et)
{
    char szTemp[255];
    int ind,inc,ok,is8_16;

    sprintf(szTemp,"eqout: %s (x%d)",szEq,et); ErrorScreen.addeqres(szTemp);

    decompose_ex(szEq);
    decompose_debug();  // decompose_ex2 not needed because nor ! nor /\� are allowed

    ///*UU*/ ErrorScreen.add("Exit from process_equation_out"); return 1;

    ind=0;
    while(1)
    {
        inc=1;
        ok=0;

        if(decomposed_string_type[ind]==TYPE_NOTHING) { ok=1; break; }

        //sprintf(szError,"wazza ind=%d",ind); ErrorScreen.add(szError);

        if(decomposed_string_type[ind]==TYPE_ZV8 || decomposed_string_type[ind]==TYPE_ZV16)
        {
            is8_16=8;
            if(decomposed_string_type[ind]==TYPE_ZV16) is8_16=16;

            if(decomposed_string_type[ind+1]==TYPE_OP)  if(decomposed_string_adrval[ind+1]=='=')
            if(decomposed_string_type[ind+2]==TYPE_LIT)
            {
                ok=1;
                inc=3;
                sprintf(szTemp,"x%d",et);
                AddLitHex("l/",szTemp ,INST_LOAD | INST_UP ,et);
                sprintf(szTemp,"%s=%d",decomposed_string[ind],decomposed_string_adrval[ind+2]);
                AddLitHexLit("=op",szTemp ,INST_OPVAREGA ,decomposed_string_adrval[ind], decomposed_string_adrval[ind+2]);
            }

            if(decomposed_string_type[ind+1]==TYPE_OP)  if(decomposed_string_adrval[ind+1]=='+')
            if(decomposed_string_type[ind+2]==TYPE_LIT)
            {
                ok=1;
                inc=3;
                sprintf(szTemp,"x%d",et);
                AddLitHex("l/",szTemp ,INST_LOAD | INST_UP ,et);
                sprintf(szTemp,"%s+%d",decomposed_string[ind],decomposed_string_adrval[ind+2]);
                AddLitHexLit("=op",szTemp ,INST_OPVARADD ,decomposed_string_adrval[ind], decomposed_string_adrval[ind+2]);
            }

            if(decomposed_string_type[ind+1]==TYPE_OP)  if(decomposed_string_adrval[ind+1]=='-')
            if(decomposed_string_type[ind+2]==TYPE_LIT)
            {
                ok=1;
                inc=3;
                sprintf(szTemp,"x%d",et);
                AddLitHex("l/",szTemp ,INST_LOAD | INST_UP ,et);
                sprintf(szTemp,"%s-%d",decomposed_string[ind],decomposed_string_adrval[ind+2]);
                AddLitHexLit("=op",szTemp ,INST_OPVARSUB ,decomposed_string_adrval[ind], decomposed_string_adrval[ind+2]);
            }

            if(decomposed_string_type[ind+1]==TYPE_OP)  if(decomposed_string_adrval[ind+1]=='+')
            if(decomposed_string_type[ind+2]==TYPE_OP)  if(decomposed_string_adrval[ind+2]=='+')
            {
                ok=1;
                inc=3;
                sprintf(szTemp,"x%d",et);
                AddLitHex("l/",szTemp ,INST_LOAD | INST_UP ,et);
                sprintf(szTemp,"%s+1",decomposed_string[ind]);
                AddLitHexLit("=op",szTemp ,INST_OPVARADD ,decomposed_string_adrval[ind], 1);
            }

            if(decomposed_string_type[ind+1]==TYPE_OP)  if(decomposed_string_adrval[ind+1]=='-')
            if(decomposed_string_type[ind+2]==TYPE_OP)  if(decomposed_string_adrval[ind+2]=='-')
            {
                ok=1;
                inc=3;
                sprintf(szTemp,"x%d",et);
                AddLitHex("l/",szTemp ,INST_LOAD | INST_UP ,et);
                sprintf(szTemp,"%s-1",decomposed_string[ind]);
                AddLitHexLit("=op",szTemp ,INST_OPVARSUB ,decomposed_string_adrval[ind], 1);
            }
        }

        if(decomposed_string_type[ind]==TYPE_ZB)
        {
            ok=1; inc=1;
            strcpy(OutEqZb_str[OutEqZb_ind],decomposed_string[ind]);
            OutEqZb_adrval[OutEqZb_ind]=decomposed_string_adrval[ind];
            OutEqZb_et[OutEqZb_ind]=et;
            OutEqZb_type[OutEqZb_ind]=TYPE_NORM;
            OutEqZb_ind++;
        }

        if(decomposed_string_type[ind+1]==TYPE_ZB)
        if(decomposed_string_type[ind]==TYPE_UNKNOWN) if(STR_SAME stricmp(decomposed_string[ind],"c") || STR_SAME stricmp(decomposed_string[ind],"clr") || STR_SAME stricmp(decomposed_string[ind],"clear"))
        {
            ok=1; inc=2;
            strcpy(OutEqZb_str[OutEqZb_ind],decomposed_string[ind+1]);
            OutEqZb_adrval[OutEqZb_ind]=decomposed_string_adrval[ind+1];
            OutEqZb_et[OutEqZb_ind]=et;
            OutEqZb_type[OutEqZb_ind]=TYPE_CLR;
            OutEqZb_ind++;
        }

        if(decomposed_string_type[ind+1]==TYPE_ZB)
        if(decomposed_string_type[ind]==TYPE_UNKNOWN) if(STR_SAME stricmp(decomposed_string[ind],"s") || STR_SAME stricmp(decomposed_string[ind],"set"))
        {
            ok=1; inc=2;
            strcpy(OutEqZb_str[OutEqZb_ind],decomposed_string[ind+1]);
            OutEqZb_adrval[OutEqZb_ind]=decomposed_string_adrval[ind+1];
            OutEqZb_et[OutEqZb_ind]=et;
            OutEqZb_type[OutEqZb_ind]=TYPE_SET;
            OutEqZb_ind++;
        }

        if(decomposed_string_type[ind]==TYPE_OP) if(decomposed_string_adrval[ind]==',')
        {
            ok=1; inc=1;
        }

        ind+=inc;

        if(ok==0) { CompileError++; sprintf(szTemp,"Line %3d: Error in out equation: %s",CurrLine+1,szEq); ErrorScreen.add(szTemp); break;}
    }

    return ok;
}


/*------------------------------------------------------------------------------
NAME  : add_trans
DESCR : ajoute la transition marquues par le symbole '-' en (x,y)
ARG   : x,y
RETURN: None
NOTES : la fin de la chaine est materialisee par 2 espaces (ou fin du tableau)
------------------------------------------------------------------------------*/
void add_trans(int x, int y)
{
    int i;
    char szEq[255];
    int first,last;
    int cpt;


    CurrLine=y;

    first=-1;last=-1;
    cpt=0;
    for(i=x+1;i<GRA_MEM_COL;i++)
    {
        if(first!=-1)
        {
            if(gra_mem[y][i]==' ') cpt++; else cpt=0;
            if(cpt==2) break;
        }

        if(gra_mem[y][i]!=' ')
        {
             if(first==-1) first=i;
             last=i;
        }
    }

    if(first!=-1)
    {
        strncpy(szEq,&gra_mem[y][first],last-first+1);
        szEq[last-first+1]='\0';
        process_equation(szEq);
    }
    else
    {
        CompileError++;
        sprintf(szError,"Line %3d (col %d): Transition missing",y+1,x+1);
        ErrorScreen.add(szError);
    }
}


#define ETAI_START 0
#define ET_START   1
#define ET_STOP    2
/*------------------------------------------------------------------------------
NAME  : add_etape
DESCR : ajoute l'etape marquues par le symbole '[' en (x,y)
ARG   : void
ARG   : x,y : coordonnees
        type: debut initiale, debut, fin
RETURN: None
NOTES:
------------------------------------------------------------------------------*/
void add_etape(int x, int y, int type)
{
    int i;
    int et=-1;
    char szEq[255];


    CurrLine=y;

    for(i=x+1;i<GRA_MEM_COL;i++)
    {
       if(gra_mem[y][i]>='0' && gra_mem[y][i]<='9') { et=atoi(&gra_mem[y][i]); break; }
    }

    if(et==-1)
    {
        CompileError++;
        sprintf(szError,"Line %3d (col %d): Etape not specified",y+1,x+1);
        ErrorScreen.add(szError);
    }
    else
    {
        if(type==ETAI_START) sprintf(szEq,"* x%d",et);
        if(type==ET_START  ) sprintf(szEq,"- x%d",et);
        if(type==ET_STOP   ) sprintf(szEq,"> x%d",et);
        process_equation(szEq);
    }
}


/*------------------------------------------------------------------------------
NAME  : add_out_etape
DESCR : ajoute les sorties de l'etape marquues par le symbole '[' en (x,y)
ARG   : void
ARG   : x,y: coordonnees
RETURN: None
NOTES:
------------------------------------------------------------------------------*/
void add_out_etape(int x, int y)
{
    int i;
    int et=-1;
    int ok;
    char szEq[255];
    int first,last;
    int cpt;
    int x2;

    for(i=x+1;i<GRA_MEM_COL;i++)
    {
       if(gra_mem[y][i]>='0' && gra_mem[y][i]<='9') { et=atoi(&gra_mem[y][i]); break; }
    }

    if(et==-1)
    {
        CompileError++;
        sprintf(szError,"Line %3d (col %d): Etape not specified",y+1,x+1);
        ErrorScreen.add(szError);
        return;
    }

    ok=0;
    for(i=x+1;i<GRA_MEM_COL;i++)
    {
       if(gra_mem[y][i]==']') { ok=1; x2=i; if(gra_mem[y][x2]==']') x2++; break; }
    }

    if(ok==0)
    {
        CompileError++;
        sprintf(szError,"Line %3d (col %d): Missing ] for Etape",y+1,x+1);
        ErrorScreen.add(szError);
        return;
    }

     first=-1;last=-1; // cherche le debut et la fin de l'equation de sortie
     cpt=0;
     for(i=x2+1;i<GRA_MEM_COL;i++)
     {
        if(first!=-1)
        {
            if(gra_mem[y][i]==' ') cpt++; else cpt=0;
            if(cpt==2) break;
        }

        if(gra_mem[y][i]!=' ')
        {
             last=i;
             if(first==-1)
             {
                 if(gra_mem[y][i]=='|' || gra_mem[y][i]=='+' || gra_mem[y][i]=='-' || gra_mem[y][i]=='[') break; // autre branche donc pas d'equation // UU-ADD 24apr2005
                 first=i;
             }
        }
     }

     if(first!=-1) //sinon pas d'erreur car peut ne pas y avoir de sorties
     {
        strncpy(szEq,&gra_mem[y][first],last-first+1);
        szEq[last-first+1]='\0';
        process_equation_out(szEq,et);
    }

}


/*------------------------------------------------------------------------------
NAME  : GetGraMemStr
DESCR : get string at given position in gra_mem array
ARG   : int x: x position in gra_mem array
        int y: y position in gra_mem array
        char* szStr: returned string
RETURN: 0: no string found
        1: string found
NOTES: spces before string are removed
------------------------------------------------------------------------------*/
int GetGraMemStr(int x, int y, char* szStr)
{
    int i;
    int step;
    char szTemp[10];

    strcpy(szStr,"");
    step=0;
    for(i=x;i<GRA_MEM_COL;i++)
    {
        if(gra_mem[y][i]==' ' || gra_mem[y][i]=='\t')
        {
            if(step==0) continue;
            else        break;
        }

        sprintf(szTemp,"%c",gra_mem[y][i]);
        strcat(szStr,szTemp);
        step=1;
    }

    return step;
}


int et_found=0;
void analyzer( int x, int y, int dir, int trans_found);
#define BAS  0
#define HAUT 1
#define DROITE 2
#define GAUCHE 3
/*------------------------------------------------------------------------------
NAME  : analyzer
DESCR : analyze la cellule x,y en poursuivant l'analyze du chemin entre 2 etapes
        qui passe par une transition
ARG   : void
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
void analyzer( int x, int y, int dir, int trans_found)
{
    //sprintf(szError,"(%03d,%03d)%d,%d>%c",x,y,dir,trans_found,gra_mem[y][x]); ErrorScreen.add(szError);

    switch(gra_mem[y][x])
    {
        case '|':   if(dir==BAS ) analyzer(x,y+1,BAS ,trans_found);
                    if(dir==HAUT) analyzer(x,y-1,HAUT,trans_found);
					break;

        case '-':   if(dir==BAS   ) { add_trans(x,y); trans_found=1; analyzer(x,y+1,BAS ,trans_found); } // prend uniquement les transition vers le bas
                    if(dir==DROITE) analyzer(x+1,y,DROITE,trans_found);
                    if(dir==GAUCHE) analyzer(x-1,y,GAUCHE,trans_found);
					break;

        case '+':   if(dir!=BAS)    analyzer(x,y-1,HAUT  ,trans_found);
                    if(dir!=HAUT)   analyzer(x,y+1,BAS   ,trans_found);
                    if(dir!=GAUCHE) analyzer(x+1,y,DROITE,trans_found);
                    if(dir!=DROITE) analyzer(x-1,y,GAUCHE,trans_found);
					break;

        case 'V':   int j,i,ok;
                    char szAnchor[100];
                    char szAnchor2[100];

                    ok=0;
                    GetGraMemStr(x+1,y,szAnchor);
                    for(j=0;j<GRA_MEM_ROW;j++) for(i=0;i<GRA_MEM_COL;i++)
                    {
                        if(gra_mem[j][i]=='Y') if(GetGraMemStr(i+1,j,szAnchor2)) if(STR_SAME stricmp(szAnchor,szAnchor2)) { analyzer(i,j+1,BAS,trans_found); ok=1; }
                    }
                    if(ok==0)
                    {
                        CompileError++;
                        sprintf(szError,"Line %3d: Cannot find entry Point for anchor %s",y+1,szAnchor);
                        ErrorScreen.add(szError);
                    }
                    break;

        default :  if(x>=1) if(gra_mem[y][x-1]=='[') if(trans_found) { add_etape(x-1,y,ET_STOP); et_found=1; }// sinon ne genere pas d'erreur pour pouvoir faire des convergence en et simplifies
                   break;
    }


    //ErrorScreen.add(".");
}


/*------------------------------------------------------------------------------
NAME  : compile_before
DESCR : compile  before PRE GRA POST
ARG   : void
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int compile_before(void)
{
    ErrorScreen.add("== compile BEFORE ==");
    AddLit("@ BEFORE\n");
    return 1;
}


/*------------------------------------------------------------------------------
NAME  : compile_pre_post
DESCR : compile  PRE or POST
ARG   : None
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int compile_pre_post()
{
    int j,i;
    char szEq[255];
    int first,last;

    for(j=0;j<GRA_MEM_ROW;j++)
    {
        CurrLine=j;

        first=-1;last=-1;
        for(i=0;i<GRA_MEM_COL;i++)
        {
            if(gra_mem[j][i]!=' ')
            {
                if(first==-1) first=i;
                last=i;
            }
        }

        if(first!=-1)
        {
            strncpy(szEq,&gra_mem[j][first],last-first+1);
            szEq[last-first+1]='\0';
            process_equation(szEq);
        }
    }

    return 1;
}


/*------------------------------------------------------------------------------
NAME  : compile_pre
DESCR : compile  PRE
ARG   : None
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int compile_pre()
{
    ErrorScreen.add("== compile PRE ==");
    AddLit("@ PRE");


    return compile_pre_post();
}


/*------------------------------------------------------------------------------
NAME  : compile_gra
DESCR : compile  before GRA
ARG   : void
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int compile_gra(void)
{
    int j,i;
    char szEq[255];
    int skip=0;  // to skip 2nd [[ of eta

    ErrorScreen.add("== compile GRA-TRANS ==");
    AddLit("@ GRA-TRANS");

    skip=0;
    for(j=0;j<GRA_MEM_ROW;j++) for(i=0;i<GRA_MEM_COL;i++)
    {
        if(skip) {skip=0; continue; }

        if(gra_mem[j][i]=='[')
        {
            et_found=0;
            if(gra_mem[j][i+1]=='[') //etai
            {
                add_etape(i,j,ETAI_START);
                analyzer(i+2,j+1,BAS,0);    //UUNEW i+2
                skip=1;
            }
            else //et
            {
                add_etape(i,j,ET_START);
                analyzer(i+1,j+1,BAS,0); //UUNEW i+1
            }
            if(et_found==0)
            {
                CompileError++;
                sprintf(szError,"Line %3d: Cannot link etape (col %d)",j+1,i+1);
                ErrorScreen.add(szError);
            }

        }
    }

    ErrorScreen.add("== compile GRA-OUT ==");
    AddLit("@ GRA-OUT");

    process_equation_out_init();
    skip=0;
    for(j=0;j<GRA_MEM_ROW;j++) for(i=0;i<GRA_MEM_COL;i++)
    {
        if(skip) {skip=0; continue; }

        if(gra_mem[j][i]=='[')
        {
            if(gra_mem[j][i+1]=='[') skip=1;
            add_out_etape(i,j);
        }
    }
    process_equation_out_rest();

    return 1;
}


/*------------------------------------------------------------------------------
NAME  : compile_post
DESCR : compile  POST
ARG   : void
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int compile_post(void)
{
    ErrorScreen.add("== compile POST ==");
    AddLit("@ POST");

    return compile_pre_post();
}


/*------------------------------------------------------------------------------
NAME  : compile_after
DESCR : compile after PRE GRA POST
ARG   : void
RETURN: 0: error
        1: ok
NOTES:
------------------------------------------------------------------------------*/
int compile_after(void)
{
    ErrorScreen.add("== compile AFTER ==");
    AddLit("@ AFTER");

    return 1;
}


/*------------------------------------------------------------------------------
NAME  : compile
DESCR : compile
ARG   : void
RETURN: 0: cannot open definition file
        1: ok
        2: other pb
NOTES: remove comments
       replace tab
------------------------------------------------------------------------------*/
int compile(void)
{
    int ret,percent;

    ret=1;
    CompileError=0;
    hex_gra_ind=0;

    pf_lit=fopen(szLitFileName,"wt"); if(pf_lit==NULL) { sprintf(szError,"Cannot create %s file",szLitFileName); ErrorScreen.add(szError); ret=0;}
    pf_hex=fopen(szHexFileName,"wt"); if(pf_lit==NULL) { sprintf(szError,"Cannot create %s file",szHexFileName); ErrorScreen.add(szError); ret=0;}

    if(ret==1) ret=compile_before();
    if(ret==1) ret=load_gra_mem("pre");
    if(ret==1) ret=compile_pre();
    if(ret==1) ret=load_gra_mem("gra");
    if(ret==1) ret=compile_gra();
    if(ret==1) ret=load_gra_mem("post");
    if(ret==1) ret=compile_post();
    if(ret==1) ret=compile_after();
    if(ret==1) AddLitHex("!","",INST_END,0);

    if(ret==1) FillHexFile();

    if(pf_lit!=NULL) fclose(pf_lit);
    if(pf_hex!=NULL) fclose(pf_hex);

    ErrorScreen.add("");
    if(ret) if(CompileError==0)
    {
        ErrorScreen.add("==>> Compilation terminated with SUCCESS <<==");
        percent=(100*hex_gra_ind)/(def_ZG_STOP-def_ZG_START); if(percent==0 && hex_gra_ind!=0) percent=1;
        sprintf(szError,"%d/%d steps used (%d/100)",hex_gra_ind/2,(def_ZG_STOP-def_ZG_START)/2,percent); ErrorScreen.add(szError);
        sprintf(szError,"Compilation terminated with SUCCESS\n\n%d/%d steps used (%d/100)",hex_gra_ind/2,(def_ZG_STOP-def_ZG_START)/2,percent);
        MessageBox(hwnd,szError,"progapi",MB_OK | MB_ICONINFORMATION);
        ret=1;
    }

    if(ret==0 || CompileError>0)
    {
        sprintf(szError,"==> Compilation failed with %d ERRORS",CompileError);
        ErrorScreen.add(szError);
        ret=0;
    }

    return ret;
}



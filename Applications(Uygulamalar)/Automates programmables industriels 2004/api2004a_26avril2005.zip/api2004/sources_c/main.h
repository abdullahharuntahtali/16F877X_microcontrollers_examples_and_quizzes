/*********************************************************************************/
/*                                                                               */
/*  PROGAPI 2004                                                                 */
/*                                                                               */
/*  main.h file                                                                  */
/*                                                                               */
/*********************************************************************************/


// Applicaton title
//#define PROGAPI_TITLE "PROGAPI 2004 (v0.1 sept 2004)"
#define PROGAPI_TITLE "PROGAPI 2004 (v1.0 nov 2004)"

// Menus
#define CM_NEWGRA       800
#define CM_OPENGRA      801
#define CM_SAVEGRA      802
#define CM_SAVEASGRA    803
#define CM_SELECTDEF    804
#define CM_EXIT         805

#define CM_COMPILE      806

#define CM_GRAPHCET     807
#define CM_CONFIG       808
#define CM_DEF          809
#define CM_LIT          810
#define CM_HEX          811

#define CM_DOWNLOADINT  812
#define CM_DOWNLOADGRA  813
#define CM_INOUT        814
#define CM_ZBZV         815
#define CM_ACTIVEGRA    816
#define CM_GRAPHIC      822
#define CM_MONITOR      817

#define CM_ABOUT        818
#define CM_HELP         819
#define CM_PERSHELP     820
#define CM_USERMANUAL   821

// Display moder
#define MODE_EDIT         0
#define MODE_RS232        1
#define MODE_SEE          2
#define MODE_CONF         3
#define MODE_ACTGRA       4
#define MODE_RS232IO      5
#define MODE_RS232ZBZV    6
#define MODE_PRES         7
#define MODE_GRAPHIC      8

// colors
#define RGB_PRESENTATION_BG    RGB(0,255,128)
#define RGB_PRESENTATION_LINE  RGB(0,0,0)
#define RGB_PRESENTATION_TXT   RGB(128,0,0)

// Edit controls
#define ID_MAIN_TEXT  1101
#define ID_ERROR_TEXT 1102
#define ID_LINE_TEXT  1103
#define ID_SEE_TEXT   1104
#define ID_CONF_TEXT  1105



Gerber RS-274x files:
clock.cmp	Top (component) side foil
clock.fab	Fab print
clock.plc	Top silkscreen
clock.sol	Bottom (solder) side foil
clock.stc	top side soldermask
clock.sts	bottom side soldermask

Excellon drill file:
clock.drd

ASCII files:
clock.gpi	Aperture file
clock.dri	drill info file
clock.drl	ASCII drill rack file

Note: bottom side foil and mask are mirrored
